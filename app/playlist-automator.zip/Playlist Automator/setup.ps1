<#
    Stremio Playlist Automator - Windows setup and launcher.

    Run it by double-clicking Start.bat, or from a terminal:

        powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1

    Switches:
        -BuildIndex       download and build the IMDb index before starting
        -RebuildIndex     rebuild the index even if one already exists
        -InstallStremio   install the Stremio desktop app via winget if missing
        -NoBrowser        do not open the builder page automatically
        -Port <number>    change the port the server listens on (default 7788)
        -Doctor           run diagnostics and exit instead of starting the server
#>

[CmdletBinding()]
param(
    [switch] $BuildIndex,
    [switch] $RebuildIndex,
    [switch] $InstallStremio,
    [switch] $NoBrowser,
    [switch] $Doctor,
    [int]    $Port = 0
)

$ErrorActionPreference = 'Stop'

# PowerShell 7.4+ turns a non-zero exit code from a native command into a thrown
# exception when ErrorActionPreference is Stop. We check exit codes by hand, so
# turn that off where it exists (harmless on Windows PowerShell 5.1).
if (Get-Variable -Name PSNativeCommandUseErrorActionPreference -Scope Global -ErrorAction SilentlyContinue) {
    $global:PSNativeCommandUseErrorActionPreference = $false
}

$root = $PSScriptRoot
if (-not $root) { $root = Split-Path -Parent $MyInvocation.MyCommand.Path }

# ------------------------------------------------------------------ #
# Output helpers - every step prints an explicit verdict.
# ------------------------------------------------------------------ #

$script:StepNumber = 0
$script:TotalSteps = 6

function Write-Head {
    Write-Host ''
    Write-Host '  Stremio Playlist Automator - setup' -ForegroundColor White
    Write-Host '  ==================================' -ForegroundColor DarkGray
    Write-Host ''
}

function Write-Step([string] $text) {
    $script:StepNumber += 1
    Write-Host ''
    Write-Host ("  [{0}/{1}] {2}" -f $script:StepNumber, $script:TotalSteps, $text) -ForegroundColor White
}

function Write-Ok([string] $text)   { Write-Host "        OK    $text" -ForegroundColor Green }
function Write-Warn([string] $text) { Write-Host "        WARN  $text" -ForegroundColor Yellow }
function Write-Fail([string] $text) { Write-Host "        FAIL  $text" -ForegroundColor Red }
function Write-Info([string] $text) { Write-Host "              $text" -ForegroundColor Gray }

function Stop-Here([string] $reason) {
    Write-Host ''
    Write-Host "  Stopped: $reason" -ForegroundColor Red
    Write-Host ''
    if ($Host.Name -eq 'ConsoleHost') {
        Write-Host '  Press any key to close this window.' -ForegroundColor DarkGray
        [void]$Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
    }
    exit 1
}

function Update-SessionPath {
    # winget updates the registry, not this already-running process. Pull the
    # machine + user PATH back in so a freshly installed node is visible now.
    $parts = @()
    foreach ($scope in @('Machine', 'User')) {
        $value = [System.Environment]::GetEnvironmentVariable('Path', $scope)
        if ($value) { $parts += $value }
    }
    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA)) {
        if (-not $base) { continue }
        foreach ($leaf in @('nodejs', 'Programs\nodejs')) {
            $guess = Join-Path $base $leaf
            if (Test-Path $guess) { $parts += $guess }
        }
    }
    $env:Path = ($parts -join ';')
}

function Get-NodeVersionText {
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) { return '' }
    try { return (& node -v 2>$null | Out-String).Trim() } catch { return '' }
}

function Get-NodeMajor {
    $raw = Get-NodeVersionText
    if ($raw -match 'v(\d+)\.') { return [int]$Matches[1] }
    return -1
}

Write-Head

# ------------------------------------------------------------------ #
# 1. Windows and PowerShell
# ------------------------------------------------------------------ #

Write-Step 'Checking Windows and PowerShell'

$onWindows = $true
if (Get-Variable -Name IsWindows -ErrorAction SilentlyContinue) { $onWindows = [bool]$IsWindows }
if (-not $onWindows) {
    Write-Fail 'This setup script targets Windows.'
    Write-Info 'On macOS or Linux just run:  node src/server.js'
    Stop-Here 'not running on Windows'
}

$psMajor = $PSVersionTable.PSVersion.Major
if ($psMajor -lt 5) {
    Write-Fail "PowerShell $($PSVersionTable.PSVersion) is too old (need 5.1 or newer)."
    Stop-Here 'PowerShell too old'
}

try {
    $os = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption
} catch {
    $os = [System.Environment]::OSVersion.VersionString
}
Write-Ok "$os, PowerShell $($PSVersionTable.PSVersion)"

# ------------------------------------------------------------------ #
# 2. Project files
# ------------------------------------------------------------------ #

Write-Step 'Checking project files'

$required = @(
    'package.json',
    'src\server.js',
    'src\web\index.html',
    'src\lib\util.js',
    'src\lib\imdb.js',
    'src\lib\seen.js',
    'src\lib\sources.js',
    'src\lib\store.js',
    'src\lib\query.js',
    'src\lib\addon.js'
)
$missing = @()
foreach ($rel in $required) {
    if (-not (Test-Path (Join-Path $root $rel))) { $missing += $rel }
}
if ($missing.Count -gt 0) {
    Write-Fail "Missing file(s): $($missing -join ', ')"
    Write-Info "Expected them under: $root"
    Write-Info 'Re-extract the folder, keeping its structure intact, and run this again.'
    Stop-Here 'incomplete project folder'
}
Write-Ok "All $($required.Count) source files present in $root"

# ------------------------------------------------------------------ #
# 3. winget
# ------------------------------------------------------------------ #

Write-Step 'Checking winget (Windows Package Manager)'

$winget = Get-Command winget -ErrorAction SilentlyContinue
if ($winget) {
    $wingetVersion = ''
    try { $wingetVersion = (& winget --version 2>$null | Out-String).Trim() } catch { }
    Write-Ok "winget $wingetVersion"
} else {
    Write-Warn 'winget is not available in this session.'
    Write-Info 'winget ships with Windows 11 as part of "App Installer". If it is missing,'
    Write-Info 'it can be installed from the Microsoft Store (the Store app is local to Windows;'
    Write-Info 'this script will not open any website).'
    $answer = Read-Host '        Open the Microsoft Store page for App Installer now? [y/N]'
    if ($answer -match '^(y|yes)$') {
        try {
            Start-Process 'ms-windows-store://pdp/?productid=9NBLGGH4NNS1'
            Write-Info 'Install App Installer in the Store, then close this window and run setup again.'
        } catch {
            Write-Fail "Could not open the Store: $($_.Exception.Message)"
        }
    }
    Write-Info 'Continuing - winget is only needed if something has to be installed.'
}

# ------------------------------------------------------------------ #
# 4. Node.js
# ------------------------------------------------------------------ #

Write-Step 'Checking Node.js (18 or newer required)'

$nodeMajor = Get-NodeMajor

if ($nodeMajor -lt 0) {
    Write-Warn 'Node.js is not installed (or not on PATH).'
} elseif ($nodeMajor -lt 18) {
    Write-Warn "Node.js v$nodeMajor found, but this app needs 18 or newer."
} else {
    Write-Ok "Node.js $(Get-NodeVersionText)"
}

if ($nodeMajor -lt 18) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Fail 'Node.js is missing and winget is not available to install it.'
        Write-Info 'Install "App Installer" from the Microsoft Store (step 3), then run setup again.'
        Stop-Here 'cannot install Node.js automatically'
    }

    Write-Info 'Installing Node.js LTS with winget. Windows will ask for permission (UAC) - accept it.'
    Write-Info 'Command: winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements'
    Write-Host ''

    & winget install -e --id OpenJS.NodeJS.LTS --source winget --accept-package-agreements --accept-source-agreements
    $wingetExit = $LASTEXITCODE
    Write-Host ''

    if ($wingetExit -ne 0) {
        Write-Warn "winget exited with code $wingetExit - verifying anyway."
    }

    Update-SessionPath
    $nodeMajor = Get-NodeMajor

    if ($nodeMajor -ge 18) {
        Write-Ok "Node.js $(Get-NodeVersionText) installed and visible in this session."
    } elseif ($nodeMajor -gt 0) {
        Write-Fail "Node.js v$nodeMajor is still the version on PATH."
        Write-Info 'An older Node.js is shadowing the new one. Uninstall it (Settings > Apps),'
        Write-Info 'or remove its folder from PATH, then run setup again.'
        Stop-Here 'old Node.js still on PATH'
    } else {
        Write-Fail 'Node.js was installed but is not visible to this window yet.'
        Write-Info 'This is normal right after an install: close this window, open a new one,'
        Write-Info 'and run Start.bat again. Nothing else needs to be done by hand.'
        Stop-Here 'PATH not refreshed yet'
    }
}

# Confirm the runtime actually works, not just that the binary resolves.
try {
    $probe = (& node -e "process.stdout.write(String(typeof fetch === 'function'))" 2>&1 | Out-String).Trim()
} catch {
    $probe = 'error'
}
if ($probe -eq 'true') {
    Write-Ok 'Node runtime works and has global fetch().'
} else {
    Write-Fail "Node.js did not respond as expected (got: $probe)."
    Write-Info 'Reinstall it with: winget install -e --id OpenJS.NodeJS.LTS --force'
    Stop-Here 'broken Node.js installation'
}

Write-Info 'No npm packages are needed - this app has zero dependencies.'

# ------------------------------------------------------------------ #
# 5. Stremio (optional)
# ------------------------------------------------------------------ #

Write-Step 'Checking Stremio desktop app (optional)'

$uninstallKeys = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
$stremio = $null
try {
    $stremio = Get-ItemProperty $uninstallKeys -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like '*Stremio*' } |
        Select-Object -First 1
} catch { }

if ($stremio) {
    Write-Ok "$($stremio.DisplayName) $($stremio.DisplayVersion)"
} elseif ($InstallStremio) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Warn 'Stremio not found and winget is unavailable - skipping.'
    } else {
        Write-Info 'Installing Stremio with winget...'
        Write-Host ''
        & winget install -e --id Stremio.Stremio --source winget --accept-package-agreements --accept-source-agreements
        $stremioExit = $LASTEXITCODE
        Write-Host ''
        if ($stremioExit -eq 0) {
            Write-Ok 'Stremio installed.'
        } else {
            Write-Warn "winget exited with code $stremioExit - install Stremio manually if it is missing."
        }
    }
} else {
    Write-Warn 'Stremio desktop app not detected.'
    Write-Info 'Install it with:  .\Start.bat -InstallStremio'
    Write-Info 'or use the web app at web.stremio.com - either one can install these playlists.'
}

# ------------------------------------------------------------------ #
# 6. Settings, index, launch
# ------------------------------------------------------------------ #

Write-Step 'Starting the local server'

$serverJs  = Join-Path $root 'src\server.js'
$storePath = (Join-Path $root 'src\lib\store.js') -replace '\\', '/'

if ($Port -gt 0) {
    if ($Port -lt 1024 -or $Port -gt 65535) {
        Write-Fail "Port $Port is out of range (1024-65535)."
        Stop-Here 'invalid port'
    }
    & node -e "require('$storePath').writeSettings({ port: $Port })"
    if ($LASTEXITCODE -eq 0) {
        Write-Ok "Port set to $Port and saved."
        Write-Info 'Playlists already installed in Stremio point at the old port - reinstall them.'
    } else {
        Write-Warn 'Could not save the port setting; using whatever is in data\settings.json.'
    }
}

if ($NoBrowser) {
    & node -e "require('$storePath').writeSettings({ openBrowser: false })" | Out-Null
    Write-Ok 'Automatic browser opening disabled.'
}

if ($Doctor) {
    Write-Info 'Running diagnostics instead of starting the server.'
    Write-Host ''
    & node $serverJs doctor
    Write-Host ''
    if ($Host.Name -eq 'ConsoleHost') {
        Write-Host '  Press any key to close this window.' -ForegroundColor DarkGray
        [void]$Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
    }
    exit 0
}

if ($BuildIndex -or $RebuildIndex) {
    Write-Info 'Building the IMDb index. First run downloads about 200 MB from IMDb; a few minutes.'
    Write-Host ''
    if ($RebuildIndex) { & node $serverJs build --force } else { & node $serverJs build }
    $buildExit = $LASTEXITCODE
    Write-Host ''
    if ($buildExit -eq 0) {
        Write-Ok 'IMDb index ready.'
    } else {
        Write-Fail "Index build failed (exit code $buildExit)."
        Write-Info 'Check your internet connection and try again; you can also build it from the'
        Write-Info 'builder page, which shows a progress bar and the exact error.'
        Stop-Here 'index build failed'
    }
}

Write-Ok 'All checks passed. Handing over to Node.'
Write-Info 'Keep this window open while you use Stremio. Press Ctrl+C to stop the server.'

& node $serverJs

$serverExit = $LASTEXITCODE
Write-Host ''
if ($serverExit -ne 0 -and $serverExit -ne $null) {
    Write-Host "  The server exited with code $serverExit. The message above explains why." -ForegroundColor Red
} else {
    Write-Host '  Server stopped.' -ForegroundColor DarkGray
}
Write-Host ''
if ($Host.Name -eq 'ConsoleHost') {
    Write-Host '  Press any key to close this window.' -ForegroundColor DarkGray
    [void]$Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
}
