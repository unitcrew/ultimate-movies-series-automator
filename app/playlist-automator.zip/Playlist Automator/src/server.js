'use strict';

/* ------------------------------------------------------------------ *
 * Runtime check first, before anything else is required.
 * ------------------------------------------------------------------ */

const NODE_MAJOR = parseInt(process.versions.node.split('.')[0], 10);

if (NODE_MAJOR < 18) {
  console.error('');
  console.error('  Node.js 18 or newer is required. You have ' + process.versions.node + '.');
  console.error('');
  console.error('  Install the current LTS with:');
  console.error('      winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements');
  console.error('');
  console.error('  Then close this window, open a new terminal, and run setup again.');
  console.error('');
  process.exit(1);
}

if (typeof fetch !== 'function') {
  console.error('');
  console.error('  This Node build has no global fetch(), which the app needs.');
  console.error('  Install Node.js 20 LTS or newer:');
  console.error('      winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements');
  console.error('');
  process.exit(1);
}

const dns = require('dns');
const fs = require('fs');
const http = require('http');
const path = require('path');
const { execFile } = require('child_process');

// Same reason as the pinned family in lib/imdb.js: a broken AAAA route turns
// into a blanket ENOTFOUND otherwise. Applies to global fetch() too.
try {
  dns.setDefaultResultOrder('ipv4first');
} catch (_) {
  /* older Node builds don't have it; the download pins family 4 itself */
}

const util = require('./lib/util');
// A data pack waiting to be put in place, and a new copy's own install id — before any data loads.
try {
  require('./lib/distribution').onStart();
} catch (err) {
  console.error('  Start-up step failed:', err.message);
}
const imdb = require('./lib/imdb');
const store = require('./lib/store');
const seen = require('./lib/seen');

// IMDb's kinds of title, by the index's kind number (shown on the movie card).
const TITLE_KIND_WORDS = ['Feature film', 'TV film', 'Series', 'Mini-series', 'Short film', 'TV short', 'Video release', 'TV special'];
const lbHelper = require('./lib/lbhelper');
const matches = require('./lib/matches');
const mostra = require('./lib/mostra');
const screenings = require('./lib/screenings');
const festivals = require('./lib/festivals');
const sources = require('./lib/sources');
const query = require('./lib/query');
const scanjobs = require('./lib/scanjobs');
const publish = require('./lib/publish');
const cloudflare = require('./lib/cloudflare');
const connections = require('./lib/connections');
const releases = require('./lib/releases');
const fresh = require('./lib/fresh');
const daily = require('./lib/daily');
const retrieve = require('./lib/retrieve');
const alerts = require('./lib/alerts');
const planner = require('./lib/planner');

/* ------------------------------------------------------------------ *
 * Publishing to GitHub Pages. After anything that can change a playlist's
 * contents, a publish is scheduled a few minutes later (debounced, so a burst
 * of edits makes one upload). It only uploads files that actually changed.
 * ------------------------------------------------------------------ */
const AUTO_PUBLISH_DELAY_MS = 3 * 60 * 1000;
let autoPublishTimer = null;

function scheduleAutoPublish(reason) {
  const s = store.readSettings();
  if (s.publishAuto !== true || !publish.isReady(s)) return; // only when switched on by hand
  clearTimeout(autoPublishTimer);
  autoPublishTimer = setTimeout(() => {
    if (publish.status().running) return scheduleAutoPublish(reason); // try again after this one
    runPublish('auto: ' + reason);
  }, AUTO_PUBLISH_DELAY_MS);
}

async function runPublish(reason) {
  const startedAt = Date.now();
  const result = await publish.publish(store.readSettings(), { reason });
  if (result.ok) {
    const s = store.readSettings();
    const patch = {
      publishedAt: Date.now(),
      publishedRepo: s.publishRepo,
      publishSubDims: result.subDims,
      publishedManifestSha: result.manifestSha,
      publishedCheckPath: result.checkPath,
      publishBundleParts: result.bundleParts, // which part each playlist lives in (kept stable)
      publishedBundles: result.bundles,
      publishedPages: result.pages, // each playlist's first page, read back by the live check
    };
    // Only changes made BEFORE this publish started are now online.
    if ((s.publishDirtyAt || 0) <= startedAt) patch.publishDirtyAt = 0;
    store.writeSettings(patch);
    await publish.verifyLive(store.readSettings());
    await updateWorkerIfOutdated();
  } else console.error('[publish]', result.error);
  return result;
}

/**
 * Combinable dropdowns need the Worker; bring it up to date when its code
 * changed (after an update of this app, and after each publish). It's the
 * user's own free Worker, deployed with the token they saved.
 */
async function updateWorkerIfOutdated() {
  const d = await connections.ensureWorkerCurrent();
  if (d) await connections.check('cloudflare').catch(() => {});
}

/**
 * Lists by release date ("last 30 days", "upcoming") and by cinema change
 * with the calendar, not with your edits: while this app runs, they're
 * republished once a day (from 06:00), if automatic publishing is on.
 */
let dailyBusy = false;
async function dailyRefreshTick() {
  const s = store.readSettings();
  if (dailyBusy || s.publishAuto !== true || !publish.isReady(s) || publish.status().running) return;
  if (!store.listPlaylists().some(releases.isDynamic)) return;
  const now = new Date();
  const sixAm = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 6).getTime();
  if (Date.now() < sixAm || (s.publishedAt || 0) >= sixAm) return;
  dailyBusy = true;
  try {
    // Today's IMDb numbers first, so the lists go out with them.
    fresh.tick(s);
    await fresh.settled();
    await screenings.ensureFresh(store.readSettings(), { wait: true }).catch(() => {});
    if (!publish.status().running) await runPublish('daily: lists by release date or cinema');
  } catch (_) {
    /* tried again at the next tick */
  } finally {
    dailyBusy = false;
  }
}

/** The last live check; while GitHub still serves the old copy, check again every 20 s. */
function liveNow(settings) {
  const live = publish.liveStatus();
  // Still rolling out (or some playlists still served old by GitHub's cache): check again.
  const pending = live && (live.current === false || (live.pages && (live.pages.wrong.length || live.pages.failed.length)));
  // …for up to 20 minutes after the publish; past that it's a real problem, shown as is.
  const recent = Date.now() - (settings.publishedAt || 0) < 20 * 60 * 1000;
  if (pending && (live.current === false || recent) && !liveChecking && Date.now() - live.checkedAt > 20000) {
    liveChecking = true;
    publish.verifyLive(settings).finally(() => { liveChecking = false; });
  }
  return live;
}
let liveChecking = false;
let releaseDry = { running: false }; // the last "preview all" dry run
let cfLive = null; // last check of the Cloudflare Worker

/** Install URLs: GitHub Pages once published there, else this PC. */
function urlsFor(settings, path, local, viaWorker = false) {
  const pub = settings.publishedRepo === settings.publishRepo ? publish.publishedUrls(settings, path, { viaWorker }) : null;
  return pub || local;
}
const hasCombos = (p) => store.versionsOf(p).some((v) => v.more.length); // some dropdowns combine (the Worker answers)
const anyCombo = () => store.listPlaylists().some(hasCombos);

/**
 * The bundle add-ons as last published (Stremio caps an add-on's size, so
 * there may be several), each at the address that serves it fully: through
 * the Worker when combinable dropdowns are in use.
 */
function bundleLinks(settings) {
  if (settings.publishedRepo !== settings.publishRepo) return [];
  const parts = Array.isArray(settings.publishedBundles) && settings.publishedBundles.length
    ? settings.publishedBundles
    : [{ part: 1, dir: 'all', name: 'My Playlists' }];
  // the bundle lives on the Worker whenever it's set up (and for combinable dropdowns anyway)
  const viaWorker = Boolean(settings.cfToken && settings.cfWorkerUrl) || anyCombo();
  return parts.map((b) => ({ ...b, urls: publish.publishedUrls(settings, `${b.dir}/manifest.json`, { viaWorker }) })).filter((b) => b.urls);
}

/*
 * The page is read from disk on every load, but this server's code is loaded
 * once at startup. After an update, a refreshed page can therefore be talking
 * to the OLD server — a mismatch that produces results neither version would.
 * Remember what the code looked like at startup and tell the page when the
 * files on disk are newer, so it can say "restart" instead of misbehaving.
 */
function newestCodeMtime() {
  let newest = 0;
  const files = [__filename];
  try {
    const lib = path.join(__dirname, 'lib');
    for (const f of fs.readdirSync(lib)) if (f.endsWith('.js')) files.push(path.join(lib, f));
  } catch (_) {
    /* best effort */
  }
  for (const f of files) {
    try {
      newest = Math.max(newest, fs.statSync(f).mtimeMs);
    } catch (_) {
      /* a file mid-replace: skip it this time */
    }
  }
  return newest;
}
const CODE_LOADED_MTIME = newestCodeMtime();
const SERVER_STARTED_AT = Date.now();
const watchsync = require('./lib/watchsync');
const { ALL_COUNTRIES, COUNTRY_GROUPS, COUNTRY_SETS } = require('./lib/countries');
const addon = require('./lib/addon');

const { DIRS } = util;

util.ensureDirs();

/* ------------------------------------------------------------------ *
 * Index build state (shared with the web page's progress bar)
 * ------------------------------------------------------------------ */

const buildState = {
  running: false,
  pct: 0,
  phase: 'idle',
  message: '',
  error: null,
  finishedAt: 0,
};

function startBuild(force) {
  if (buildState.running) return { started: false, reason: 'A build is already running.' };
  if (imdb.indexExists() && !force) return { started: false, reason: 'Index already exists.' };

  const settings = store.readSettings();
  buildState.running = true;
  buildState.error = null;
  buildState.pct = 0;
  buildState.phase = 'starting';
  buildState.message = 'Contacting IMDb…';

  imdb
    .buildIndex({
      minVotes: settings.indexMinVotes,
      onProgress: (state) => {
        buildState.pct = state.pct;
        buildState.phase = state.phase;
        buildState.message = state.message;
      },
    })
    .then((res) => {
      buildState.running = false;
      buildState.pct = 100;
      buildState.phase = 'done';
      buildState.message = `Index ready: ${res.count.toLocaleString('en-US')} titles.`;
      buildState.finishedAt = Date.now();
      imdb.invalidate();
      query.clearOrderCache();
      seen.invalidateCache();
    })
    .catch((err) => {
      buildState.running = false;
      buildState.phase = 'error';
      buildState.error = err.message;
      buildState.message = `Build failed: ${err.message}`;
    });

  return { started: true };
}

/* ------------------------------------------------------------------ *
 * HTTP helpers
 * ------------------------------------------------------------------ */

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Filename');
}

function sendJson(res, status, payload, extraHeaders) {
  const body = Buffer.from(JSON.stringify(payload));
  setCors(res);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    ...(extraHeaders || {}),
  });
  res.end(body);
}

function sendText(res, status, text, contentType) {
  const body = Buffer.from(String(text));
  setCors(res);
  res.writeHead(status, {
    'Content-Type': contentType || 'text/plain; charset=utf-8',
    'Content-Length': body.length,
  });
  res.end(body);
}

function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', (chunk) => {
      total += chunk.length;
      if (total > maxBytes) {
        reject(new Error(`Upload is larger than ${Math.round(maxBytes / 1048576)} MB.`));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function readJsonBody(req) {
  const buf = await readBody(req, 4 * 1024 * 1024);
  if (!buf.length) return {};
  return JSON.parse(buf.toString('utf8'));
}

/* ------------------------------------------------------------------ *
 * API
 * ------------------------------------------------------------------ */


function indexSummary() {
  const stat = imdb.indexStat();
  if (!stat.exists) return { exists: false };
  try {
    const index = imdb.loadIndex();
    return {
      exists: true,
      count: index.count,
      genres: index.genres,
      minVotes: index.minVotes,
      builtAt: index.builtAt,
      bytes: stat.bytes,
      years: index.years,
      meanRating: index.meanRating,
      kinds: index.kinds, // has 'short' once rebuilt with every film-like title
    };
  } catch (err) {
    return { exists: true, error: err.message === 'INDEX_STALE' ? 'Index was built by an older version — rebuild it.' : err.message };
  }
}

function seenSummary() {
  return seen.listProfiles().map((name) => ({
    name,
    files: seen.listProfileFiles(name),
  }));
}

function maskKey(key) {
  if (!key) return '';
  if (key.length <= 8) return '••••';
  return `${key.slice(0, 4)}••••${key.slice(-4)}`;
}

async function handleApi(req, res, pathname, url) {
  const settings = store.readSettings();

  // Anything that can change what a playlist contains schedules a publish.
  if (req.method !== 'GET' && !/^\/api\/(preview|release-preview|scan|publish|cloudflare|connections|letterboxd|lbhelper|cinemas\/refresh|imdb\/test|title\/|rerank|fresh|alerts|mostra\/plan|retrieve|daily|app\/|datapack)/.test(pathname)) {
    store.writeSettings({ publishDirtyAt: Date.now() }); // "unpublished changes"
    scheduleAutoPublish(pathname);
  }

  /* ---------- Release preview: what Stremio will get, before publishing ---------- */
  // The Letterboxd helper add-on in the user's browser (see lib/lbhelper.js).
  if (pathname === '/api/lbhelper/next' && req.method === 'POST') {
    return sendJson(res, 200, lbHelper.next(await readJsonBody(req).catch(() => ({}))));
  }
  if (pathname === '/api/lbhelper/test' && req.method === 'POST') {
    if (!lbHelper.connected()) {
      return sendJson(res, 200, { ok: false, message: 'Not connected. Install it (steps above), make sure it is switched on, and keep this page open in that same browser — then test again.' });
    }
    const t0 = Date.now();
    try {
      const r = await lbHelper.fetchViaHelper('https://letterboxd.com/csi/film/escapade/rating-histogram/', 20000);
      if (r.headers.get('cf-mitigated')) return sendJson(res, 200, { ok: false, message: 'Connected, but Letterboxd asked your browser to confirm a person: a tab with the film should have opened — tick the box there and test again.' });
      const h = sources.parseLetterboxdHistogram(r.text);
      if (!r.ok || !h.n) return sendJson(res, 200, { ok: false, message: `Connected, but the test read failed (HTTP ${r.status}).` });
      return sendJson(res, 200, { ok: true, message: `Working: read Escapade (1935) — ${h.n} ratings averaging ${h.avg.toFixed(2)} — in ${((Date.now() - t0) / 1000).toFixed(1)} s.` });
    } catch (err) {
      return sendJson(res, 200, { ok: false, message: err.message });
    }
  }
  if (pathname === '/api/lbhelper/result' && req.method === 'POST') {
    return sendJson(res, 200, lbHelper.result(await readJsonBody(req).catch(() => ({}))));
  }
  if (pathname === '/api/release-preview' && req.method === 'POST') {
    const body = await readJsonBody(req);
    if (!imdb.indexExists()) return sendJson(res, 200, { error: 'The IMDb index has not been built yet.' });
    try {
      return sendJson(res, 200, await publish.releasePreview(body.playlist || {}, settings));
    } catch (err) {
      return sendJson(res, 200, { error: err.message });
    }
  }
  if (pathname === '/api/release-preview/all') {
    // A dry run of the whole publish (nothing is uploaded): every playlist,
    // the "My Playlists" part it lands in, and what each catalog will show.
    if (req.method === 'POST' && !releaseDry.running) {
      releaseDry = { running: true, step: 'Starting…', startedAt: Date.now() };
      publish.buildSite(store.readSettings(), (step) => { releaseDry.step = step; })
        .then((r) => {
          const names = new Map(store.listPlaylists().map((p) => [p.slug, p.name]));
          const parts = r.bundles.map((b) => ({ part: b.part, name: b.name, bytes: b.bytes,
            playlists: Object.entries(r.bundleParts).filter(([, k]) => k === b.part).map(([slug]) => ({ slug, name: names.get(slug) || slug })) }));
          // in the app's order within each part
          const order = store.listPlaylists().map((p) => p.slug);
          for (const part of parts) part.playlists.sort((a, b) => order.indexOf(a.slug) - order.indexOf(b.slug));
          releaseDry = { running: false, finishedAt: Date.now(), ok: true, parts, previews: r.previews, audit: r.audit, errors: r.errors, files: r.files.size,
            worker: Boolean(store.readSettings().cfToken && store.readSettings().cfWorkerUrl), previousParts: store.readSettings().publishBundleParts || {} };
        })
        .catch((err) => { releaseDry = { running: false, ok: false, error: err.message }; });
    }
    return sendJson(res, 200, releaseDry);
  }

  if (pathname === '/api/publish' && req.method === 'GET') {
    return sendJson(res, 200, {
      repo: settings.publishRepo || '',
      hasToken: Boolean(settings.publishToken), // the key itself never leaves this PC's disk
      auto: settings.publishAuto === true,
      url: publish.pagesBase(settings.publishRepo),
      publishedAt: settings.publishedRepo === settings.publishRepo ? settings.publishedAt || null : null,
      dirty: Boolean(settings.publishDirtyAt),
      live: liveNow(settings),
      status: publish.status(),
      bundles: bundleLinks(settings),
    });
  }

  if (pathname === '/api/publish/settings' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const patch = {};
    if (typeof body.repo === 'string') {
      const repo = body.repo.trim().replace(/^https?:\/\/github\.com\//, '').replace(/\.git$/, '').replace(/\/$/, '');
      if (repo && !publish.parseRepo(repo)) return sendJson(res, 200, { ok: false, error: 'Use the form owner/repository, e.g. unitcrew/ultimate-movies-series-automator.' });
      patch.publishRepo = repo;
    }
    if (typeof body.token === 'string' && body.token.trim()) patch.publishToken = body.token.trim();
    if (body.clearToken) patch.publishToken = '';
    if (body.auto !== undefined) patch.publishAuto = Boolean(body.auto);
    store.writeSettings(patch);
    return sendJson(res, 200, { ok: true });
  }

  /* ---------- Settings: every outside service, checked for real ---------- */
  if (pathname === '/api/connections' && req.method === 'GET') {
    const only = url.searchParams.get('only');
    if (only) await connections.check(only);
    else if (url.searchParams.get('refresh') || !connections.snapshot().services.every((s) => s.checkedAt)) await connections.checkAll();
    return sendJson(res, 200, connections.snapshot());
  }

  if (pathname === '/api/letterboxd' && req.method === 'GET') return sendJson(res, 200, sources.letterboxdHealth());
  if (pathname === '/api/letterboxd/audit' && req.method === 'GET') {
    if (!imdb.indexExists()) return sendJson(res, 200, { error: 'The IMDb index has not been built yet.' });
    return sendJson(res, 200, sources.letterboxdAudit(imdb.loadIndex()));
  }
  if (pathname === '/api/letterboxd/window/test' && req.method === 'POST') return sendJson(res, 200, await sources.testLetterboxdWindow());
  if (pathname === '/api/letterboxd/window/front' && req.method === 'POST') {
    await sources.bringLetterboxdWindowToFront();
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === '/api/connections/enable' && req.method === 'POST') {
    const body = await readJsonBody(req);
    connections.setEnabled(String(body.id || ''), Boolean(body.enabled));
    query.clearOrderCache();
    await connections.check(String(body.id || ''));
    return sendJson(res, 200, connections.snapshot());
  }

  if (pathname === '/api/connections/save' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const id = String(body.id || '');
    const patch = {};
    const key = typeof body.key === 'string' ? body.key.trim() : '';
    if (id === 'tmdb' && key) patch.tmdbKey = key;
    if (id === 'omdb' && key) patch.omdbKey = key;
    if (id === 'trakt' && key) patch.traktClientId = key;
    if (id === 'github') {
      if (key) patch.publishToken = key;
      if (typeof body.repo === 'string') {
        const repo = body.repo.trim().replace(/^https?:\/\/github\.com\//, '').replace(/\.git$/, '').replace(/\/$/, '');
        if (repo && !publish.parseRepo(repo)) return sendJson(res, 200, { ok: false, error: 'Use the form owner/repository, e.g. unitcrew/ultimate-movies-series-automator.' });
        patch.publishRepo = repo;
      }
      if (body.auto !== undefined) patch.publishAuto = Boolean(body.auto);
    }
    if (id === 'letterboxd' && body.histograms !== undefined) {
      patch.lbHistograms = Boolean(body.histograms);
      sources.setLetterboxdHistograms(patch.lbHistograms);
    }
    if (id === 'letterboxd' && body.window !== undefined) {
      patch.lbWindow = Boolean(body.window);
      sources.setLetterboxdWindowMode(patch.lbWindow);
    }
    if (id === 'cloudflare') {
      if (key) patch.cfToken = key;
      if (typeof body.accountId === 'string') patch.cfAccountId = body.accountId.trim().replace(/[^A-Za-z0-9]/g, '');
    }
    if (body.clearKey) {
      const k = { tmdb: 'tmdbKey', omdb: 'omdbKey', trakt: 'traktClientId', github: 'publishToken', cloudflare: 'cfToken' }[id];
      if (k) patch[k] = '';
    }
    store.writeSettings(patch);
    query.clearOrderCache();
    await connections.check(id);
    return sendJson(res, 200, { ok: true, ...connections.snapshot() });
  }

  /* ---------- Cloudflare: the combinable-dropdowns Worker ---------- */
  if (pathname === '/api/cloudflare' && req.method === 'GET') {
    return sendJson(res, 200, {
      hasToken: Boolean(settings.cfToken), // the token itself never leaves this PC's disk
      accountId: settings.cfAccountId || '',
      url: settings.cfWorkerUrl || '',
      deployedAt: settings.cfDeployedAt || null,
      status: cloudflare.status(),
      live: cfLive,
    });
  }

  if (pathname === '/api/cloudflare/settings' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const patch = {};
    if (typeof body.token === 'string' && body.token.trim()) patch.cfToken = body.token.trim();
    if (body.clearToken) patch.cfToken = '';
    if (typeof body.accountId === 'string') patch.cfAccountId = body.accountId.trim().replace(/[^A-Za-z0-9]/g, '');
    store.writeSettings(patch);
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === '/api/cloudflare/deploy' && req.method === 'POST') {
    if (!cloudflare.status().running) {
      cloudflare.deploy(settings, publish.pagesBase(settings.publishRepo)).then(async (r) => {
        if (!r.ok) return;
        store.writeSettings({ cfWorkerUrl: r.url, cfAccountId: r.accountId, cfDeployedAt: Date.now(), cfWorkerVersion: r.version });
        // A brand-new workers.dev address can take a little while to answer.
        // (DNS for it can take a few minutes; keep trying for ~5.)
        for (let i = 0; i < 20; i += 1) {
          cfLive = await cloudflare.verify(r.url);
          if (cfLive && cfLive.status === 200) break;
          await new Promise((ok) => setTimeout(ok, 15000));
        }
        await connections.check('cloudflare');
      });
    }
    return sendJson(res, 200, { ok: true, status: cloudflare.status() });
  }

  if (pathname === '/api/cloudflare/verify' && req.method === 'POST') {
    cfLive = await cloudflare.verify(settings.cfWorkerUrl);
    return sendJson(res, 200, { live: cfLive });
  }

  if (pathname === '/api/publish/verify' && req.method === 'POST') {
    return sendJson(res, 200, { live: await publish.verifyLive(settings) });
  }

  if (pathname === '/api/publish/run' && req.method === 'POST') {
    if (!publish.isReady(settings)) return sendJson(res, 200, { ok: false, error: 'Set the repository and the key first.' });
    if (!publish.status().running) runPublish('manual');
    return sendJson(res, 200, { ok: true, status: publish.status() });
  }

  if (pathname === '/api/state' && req.method === 'GET') {
    return sendJson(res, 200, {
      node: process.versions.node,
      port: settings.port,
      host: `127.0.0.1:${settings.port}`,
      index: indexSummary(),
      build: buildState,
      serverStartedAt: SERVER_STARTED_AT,
      codeOutdated: newestCodeMtime() > CODE_LOADED_MTIME + 1000,
      playlists: withUrls(store.listPlaylists(), settings),
      seen: seenSummary(),
      countries: ALL_COUNTRIES,
      countryGroups: COUNTRY_GROUPS,
      countrySets: COUNTRY_SETS,
      settings: {
        region: settings.region,
        indexMinVotes: settings.indexMinVotes,
        hasTmdbKey: Boolean(settings.tmdbKey),
        tmdbKeyMasked: maskKey(settings.tmdbKey),
        hasOmdbKey: Boolean(settings.omdbKey),
        omdbKeyMasked: maskKey(settings.omdbKey),
        openBrowser: settings.openBrowser,
      },
      customListName: seen.CUSTOM_FILE,
      defaults: store.blankPlaylist(),
      maxLimit: store.MAX_LIMIT,
      installState: installState(settings),
      bundle: { urls: urlsFor(settings, 'all/manifest.json', addon.bundleInstallUrls({ host: `127.0.0.1:${settings.port}` }), anyCombo()) },
      account: watchsync.accountStatus(),
      cache: sources.cacheStats(),
      imdb: sources.imdbStatus(),
      blocked: store.listBlocked().length,
      downloadsDir: settings.downloadsDir || '',
    });
  }

  if (pathname === '/api/settings' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const patch = {};
    if (typeof body.tmdbKey === 'string') patch.tmdbKey = body.tmdbKey.trim();
    if (typeof body.omdbKey === 'string') patch.omdbKey = body.omdbKey.trim();
    if (typeof body.downloadsDir === 'string') patch.downloadsDir = body.downloadsDir.trim();
    if (body.autoSync !== undefined) patch.autoSync = Boolean(body.autoSync);
    if (body.region) patch.region = String(body.region).toUpperCase().slice(0, 2);
    if (body.indexMinVotes !== undefined) patch.indexMinVotes = body.indexMinVotes;
    if (body.openBrowser !== undefined) patch.openBrowser = Boolean(body.openBrowser);
    const next = store.writeSettings(patch);
    query.clearOrderCache();
    return sendJson(res, 200, {
      ok: true,
      hasTmdbKey: Boolean(next.tmdbKey),
      hasOmdbKey: Boolean(next.omdbKey),
      region: next.region,
    });
  }

  if (pathname === '/api/tmdb/verify' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const key = typeof body.tmdbKey === 'string' && body.tmdbKey.trim() ? body.tmdbKey.trim() : settings.tmdbKey;
    if (!key) return sendJson(res, 200, { ok: false, message: 'No key entered.' });
    const result = await sources.verifyKey(key);
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/omdb/verify' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const key = typeof body.omdbKey === 'string' && body.omdbKey.trim() ? body.omdbKey.trim() : settings.omdbKey;
    return sendJson(res, 200, await sources.verifyOmdbKey(key));
  }

  if (pathname === '/api/tmdb/regions' && req.method === 'GET') {
    if (!settings.tmdbKey) return sendJson(res, 200, { regions: [] });
    try {
      return sendJson(res, 200, { regions: await sources.listRegions(settings.tmdbKey) });
    } catch (err) {
      return sendJson(res, 200, { regions: [], error: err.message });
    }
  }

  if (pathname === '/api/tmdb/providers' && req.method === 'GET') {
    if (!settings.tmdbKey) return sendJson(res, 200, { providers: [] });
    const region = (url.searchParams.get('region') || settings.region || 'US').toUpperCase();
    const type = url.searchParams.get('type') === 'series' ? 'series' : 'movie';
    try {
      return sendJson(res, 200, { providers: await sources.listProviders(settings.tmdbKey, type, region), region });
    } catch (err) {
      return sendJson(res, 200, { providers: [], error: err.message });
    }
  }

  if (pathname === '/api/index/build' && req.method === 'POST') {
    const body = await readJsonBody(req).catch(() => ({}));
    const result = startBuild(Boolean(body.force));
    return sendJson(res, result.started ? 202 : 409, result.started ? { ok: true } : { ok: false, error: result.reason });
  }

  if (pathname === '/api/index/progress' && req.method === 'GET') {
    return sendJson(res, 200, { build: buildState, index: indexSummary() });
  }

  if (pathname === '/api/preview' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const playlist = store.normalizePlaylist(body.playlist || body);
    if (!imdb.indexExists()) {
      return sendJson(res, 200, { error: 'The IMDb index has not been built yet.', metas: [] });
    }
    const started = Date.now();
    if (body.fresh) { query.clearOrderCache(); releases.forgetFailures(); } // "Update": rebuild the list from scratch
    try {
      const result = await query.runQuery(playlist, settings, {
        skip: 0,
        limit: util.clampInt(body.limit, 1, store.MAX_LIMIT, 24),
        scanCap: util.clampInt(body.scanCap, 200, 20000, 1500),
        markWatched: true,
        watchedProfiles: Array.isArray(body.watchedProfiles) ? body.watchedProfiles : [],
      });
      return sendJson(res, 200, {
        metas: result.metas,
        diagnostics: result.diagnostics,
        ms: Date.now() - started,
        description: store.describePlaylist(playlist),
      });
    } catch (err) {
      if (err.message === 'INDEX_STALE') {
        return sendJson(res, 200, { error: 'The index was built by an older version. Rebuild it.', metas: [] });
      }
      return sendJson(res, 200, { error: err.message, metas: [] });
    }
  }

  if (pathname === '/api/scan' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const playlist = store.normalizePlaylist(body.playlist || body);
    if (!imdb.indexExists()) {
      return sendJson(res, 200, { done: true, error: 'The IMDb index has not been built yet.', metas: [] });
    }
    try {
      if (body.fresh) releases.forgetFailures();
      if (body.fresh) scanjobs.forgetScan(playlist, settings, { search: body.search || '', genreOverride: body.genreOverride || '' });
      const status = await scanjobs.requestScan(playlist, settings, {
        resume: Boolean(body.resume),
        search: body.search || '',
        genreOverride: body.genreOverride || '',
        watchedProfiles: Array.isArray(body.watchedProfiles) ? body.watchedProfiles : [],
        target: util.clampInt(body.target, 1, store.MAX_LIMIT, 24),
        continue: Boolean(body.continue),
        untilDone: Boolean(body.untilDone),
      });
      return sendJson(res, 200, { ...status, description: store.describePlaylist(playlist) });
    } catch (err) {
      return sendJson(res, 200, { done: true, error: err.message, metas: [] });
    }
  }

  const scanPollMatch = pathname.match(/^\/api\/scan\/([a-f0-9]+)$/i);
  if (scanPollMatch && req.method === 'GET') {
    const jobId = scanPollMatch[1];
    const status = scanjobs.pollScan(jobId, {
      limit: util.clampInt(url.searchParams.get('limit'), 1, store.MAX_LIMIT, 100),
      watchedProfiles: (url.searchParams.get('watched') || '').split(',').filter(Boolean),
    });
    if (!status) return sendJson(res, 404, { error: 'Unknown or expired scan job.' });
    return sendJson(res, 200, status);
  }

  const scanStopMatch = pathname.match(/^\/api\/scan\/([a-f0-9]+)\/stop$/i);
  if (scanStopMatch && req.method === 'POST') {
    return sendJson(res, 200, { ok: scanjobs.stopScan(scanStopMatch[1]) });
  }

  /* ---------- Update all playlists ---------- */
  if (pathname === '/api/update-all' && req.method === 'GET') {
    return sendJson(res, 200, { ...scanjobs.updateAllStatus(), build: buildState.running || buildState.phase === 'error' ? buildState : null });
  }
  if (pathname === '/api/update-all' && req.method === 'POST') {
    if (!imdb.indexExists()) return sendJson(res, 200, { running: false, error: 'The IMDb index has not been built yet.' });
    const body = await readJsonBody(req).catch(() => ({}));
    // First the latest IMDb data (new titles, new votes), when asked.
    const before = body.rebuild
      ? async (run) => {
        const started = startBuild(true);
        if (!started.started && !buildState.running) throw new Error(started.reason);
        while (buildState.running && !run.cancelled) await util.sleep(1000);
        if (buildState.phase === 'error') throw new Error(`Downloading the IMDb data failed: ${buildState.error}`);
        run.index = { builtAt: Date.now(), message: buildState.message };
      }
      : null;
    return sendJson(res, 200, scanjobs.startUpdateAll(store.listPlaylists(), store.readSettings(), { all: Boolean(body.all), before }));
  }
  if (pathname === '/api/update-all/cancel' && req.method === 'POST') {
    return sendJson(res, 200, { ok: scanjobs.cancelUpdateAll() });
  }

  /* ---------- Cinemas (Ingresso.com) ---------- */
  if (pathname === '/api/cinemas/cities' && req.method === 'GET') {
    if (!store.serviceEnabled('ingresso')) return sendJson(res, 200, { needs: 'ingresso', error: 'Cinemas (Ingresso.com) is switched off in Settings.' });
    try {
      return sendJson(res, 200, { cities: await releases.cities() });
    } catch (err) {
      return sendJson(res, 200, { error: err.message });
    }
  }
  if (pathname === '/api/cinemas/theaters' && req.method === 'GET') {
    if (!store.serviceEnabled('ingresso')) return sendJson(res, 200, { needs: 'ingresso', error: 'Cinemas (Ingresso.com) is switched off in Settings.' });
    try {
      return sendJson(res, 200, { theaters: await releases.theaters(String(url.searchParams.get('city') || '').replace(/[^0-9]/g, '')) });
    } catch (err) {
      return sendJson(res, 200, { error: err.message });
    }
  }

  const scanCancelMatch = pathname.match(/^\/api\/scan\/([a-f0-9]+)\/cancel$/i);
  if (scanCancelMatch && req.method === 'POST') {
    return sendJson(res, 200, { ok: scanjobs.cancelScan(scanCancelMatch[1]) });
  }

  if (pathname === '/api/populate' && req.method === 'POST') {
    if (!imdb.indexExists()) {
      return sendJson(res, 200, { running: false, error: 'The IMDb index has not been built yet.' });
    }
    const body = await readJsonBody(req).catch(() => ({}));
    if (body.mode === 'refresh-tmdb' && !settings.tmdbKey) {
      return sendJson(res, 200, { running: false, needs: 'tmdb', error: 'Updating TMDB vote counts needs TMDB (Settings).' });
    }
    if (/letterboxd/.test(body.mode || '') && !sources.letterboxdEnabled()) {
      return sendJson(res, 200, { running: false, needs: 'letterboxd', error: 'Letterboxd is switched off in Settings.' });
    }
    if (body.mode === 'series-second' && !settings.tmdbKey && !settings.traktClientId) {
      return sendJson(res, 200, { running: false, needs: 'tmdb', error: 'Series ratings come from TMDB (and Trakt): set up at least one in Settings.' });
    }
    if (body.mode === 'letterboxd-list') {
      // This playlist's titles as it stands, before any Letterboxd re-rank
      // (which would leave out exactly the titles that have no rating yet).
      const pl = store.normalizePlaylist(body.playlist || {});
      const pick = { ...pl, lbRerank: false };
      if (query.lbOnly(pl) || pl.sortBy === 'letterboxd') pick.sortBy = 'weighted';
      const ids = [];
      const seriesIds = [];
      for (const type of query.typesFor(pick)) {
        const scoped = pick.type === 'all' ? { ...pick, type } : pick;
        const r = await query.runQuery(scoped, settings, { limit: pick.limit, scanCap: Infinity, lookupCap: query.FULL_SCAN_LOOKUPS });
        for (const m of r.metas) { ids.push(m.id); if (m.type === 'series') seriesIds.push(m.id); }
      }
      return sendJson(res, 200, scanjobs.startPopulate(settings, { mode: 'letterboxd-list', ids, seriesIds, label: pl.name }));
    }
    return sendJson(res, 200, scanjobs.startPopulate(settings, {
      extras: body.extras !== false,
      mode: ['letterboxd', 'refresh-letterboxd', 'refresh-tmdb', 'repair-letterboxd', 'letterboxd-top', 'series-second'].includes(body.mode) ? body.mode : 'countries',
      ceiling: util.clampInt(body.ceiling, 0, 400000, 25000),
      maxAgeDays: util.clampInt(body.maxAgeDays, 1, 365, 30),
    }));
  }

  // How old each rating source is: drives the Update panel and the reminder.
  if (pathname === '/api/freshness' && req.method === 'GET') {
    const idx = indexSummary();
    const builtAt = idx.exists && idx.builtAt ? new Date(idx.builtAt).getTime() : null;
    return sendJson(res, 200, {
      imdb: { builtAt, ageDays: builtAt ? Math.floor((Date.now() - builtAt) / 86400000) : null },
      ...sources.ratingsFreshness({ staleDays: 60 }), // what the reminder judges by
      due: (() => {
        // what an Update would actually re-fetch (older than 30 days)
        const f = sources.ratingsFreshness({ staleDays: 30 });
        return { letterboxd: f.letterboxd.stale, tmdb: f.tmdb.stale };
      })(),
      hasTmdbKey: Boolean(settings.tmdbKey),
    });
  }

  if (pathname === '/api/populate' && req.method === 'GET') {
    return sendJson(res, 200, scanjobs.populateStatus());
  }

  if (pathname === '/api/populate/cancel' && req.method === 'POST') {
    return sendJson(res, 200, { ok: scanjobs.cancelPopulate() });
  }

  const droppedMatch = pathname.match(/^\/api\/scan\/([a-f0-9]+)\/(dropped|retry)$/i);
  if (droppedMatch) {
    const out = droppedMatch[2] === 'dropped' ? scanjobs.scanDropped(droppedMatch[1]) : scanjobs.retryScanDropped(droppedMatch[1]);
    if (!out) return sendJson(res, 404, { error: 'Unknown or expired scan job.' });
    return sendJson(res, 200, out);
  }
  if (pathname === '/api/populate/dropped' && req.method === 'GET') return sendJson(res, 200, scanjobs.populateDropped());
  if (pathname === '/api/populate/retry' && req.method === 'POST') return sendJson(res, 200, scanjobs.retryPopulateDropped());
  const exportMatch = pathname.match(/^\/api\/export\/(watched|watchlist|playlist)(?:\/([a-z0-9-]+))?\.csv$/);
  if (exportMatch && req.method === 'GET') {
    const kind = exportMatch[1];
    let index = null;
    try {
      index = imdb.loadIndex();
    } catch (_) {
      return sendText(res, 400, 'Build the IMDb index first.');
    }
    let ids = [];
    let metas = null;
    let name = kind;
    if (kind === 'playlist') {
      const pl = store.getPlaylist(exportMatch[2] || '');
      if (!pl) return sendText(res, 404, 'No playlist with that id.');
      name = pl.slug;
      const result = await query.runQuery(pl, settings, { limit: pl.limit, scanCap: Infinity, lookupCap: query.FULL_SCAN_LOOKUPS });
      ids = result.metas.map((m) => m.id);
      metas = result.metas;
    } else {
      const sets = query.seenSetsFor({ type: 'all', seenProfiles: [] }, index);
      ids = [...(kind === 'watched' ? sets.seen : sets.watchlist)];
    }
    const csv = watchsync.exportCsv(ids, index, metas);
    setCors(res);
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${kind === 'playlist' ? `${name}-playlist` : kind}.csv"`,
      'Content-Length': Buffer.byteLength(csv),
    });
    return res.end(csv);
  }

  if (pathname === '/api/watchlist/sync' && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      return sendJson(res, 200, await watchsync.startWatchlistSync(body.profile));
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  if (pathname === '/api/watchlist/status' && req.method === 'GET') return sendJson(res, 200, watchsync.watchlistStatus());

  if (pathname === '/api/cache/stats' && req.method === 'GET') return sendJson(res, 200, sources.cacheStats());

  if (pathname === '/api/playlists/order' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const order = body.reset ? store.resetPlaylistOrder() : store.setPlaylistOrder(body.slugs);
    return sendJson(res, 200, { order, playlists: withUrls(store.listPlaylists(), settings), installState: installState(store.readSettings()) });
  }

  // The page calls this when an Install button is clicked, so it can later
  // tell which installs Stremio is still holding an outdated manifest for.
  if (pathname === '/api/installed' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const hashes = { ...(settings.installedHashes || {}) };
    const base = `http://127.0.0.1:${settings.port}`;
    if (body.slug === '__all') hashes.__all = addon.manifestHash(addon.buildBundleManifest({ baseUrl: base }));
    else {
      const pl = store.getPlaylist(body.slug);
      if (!pl) return sendJson(res, 404, { error: 'Unknown playlist.' });
      hashes[pl.slug] = addon.manifestHash(addon.buildManifest(pl, { baseUrl: base }));
    }
    store.writeSettings({ installedHashes: hashes });
    return sendJson(res, 200, { ok: true, installState: installState(store.readSettings()) });
  }

  /* ---- TMDB account, watched-list sync, Downloads watcher ---- */
  if (pathname === '/api/tmdb/account' && req.method === 'GET') return sendJson(res, 200, watchsync.accountStatus());
  if (pathname === '/api/tmdb/link/start' && req.method === 'POST') {
    try {
      return sendJson(res, 200, await watchsync.startLink(`http://127.0.0.1:${settings.port}/tmdb/callback`));
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  if (pathname === '/api/tmdb/link/finish' && req.method === 'POST') {
    const body = await readJsonBody(req).catch(() => ({}));
    try {
      return sendJson(res, 200, await watchsync.finishLink(body.requestToken));
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  if (pathname === '/api/tmdb/unlink' && req.method === 'POST') return sendJson(res, 200, await watchsync.unlink());
  if (pathname === '/api/sync/start' && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      return sendJson(res, 200, await watchsync.startSync(body.profile));
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  if (pathname === '/api/sync/status' && req.method === 'GET') return sendJson(res, 200, watchsync.syncStatus());
  if (pathname === '/api/watch/start' && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      return sendJson(res, 200, await watchsync.startWatch({ kind: body.kind, profile: body.profile }));
    } catch (err) {
      return sendJson(res, 400, { error: err.message });
    }
  }
  if (pathname === '/api/watch/status' && req.method === 'GET') {
    const w = watchsync.watchStatus();
    const r = w.profile ? watchsync.resolveStatus(w.profile) : null;
    return sendJson(res, 200, { ...w, resolve: r, profiles: w.state === 'imported' ? seenSummary() : undefined });
  }
  if (pathname === '/api/watch/stop' && req.method === 'POST') {
    watchsync.stopWatch();
    return sendJson(res, 200, watchsync.watchStatus());
  }
  if (pathname === '/api/resolve/status' && req.method === 'GET') {
    return sendJson(res, 200, watchsync.resolveStatus(url.searchParams.get('profile') || ''));
  }

  if (pathname === '/api/playlists' && req.method === 'GET') {
    return sendJson(res, 200, { playlists: withUrls(store.listPlaylists(), settings) });
  }

  if (pathname === '/api/playlists' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const saved = store.savePlaylist(body.playlist || body);
    query.clearOrderCache();
    return sendJson(res, 200, {
      playlist: saved,
      urls: urlsFor(settings, `p/${saved.slug}/manifest.json`, addon.installUrls(saved, { host: `127.0.0.1:${settings.port}` }), hasCombos(saved)),
      manifestId: addon.addonId(saved.slug),
    });
  }

  const playlistMatch = pathname.match(/^\/api\/playlists\/([a-z0-9-]+)$/);
  if (playlistMatch && req.method === 'DELETE') {
    store.deletePlaylist(playlistMatch[1]);
    query.clearOrderCache();
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === '/api/seen' && req.method === 'GET') {
    return sendJson(res, 200, { profiles: seenSummary() });
  }

  const uploadMatch = pathname.match(/^\/api\/seen\/([A-Za-z0-9._-]+)\/files$/);
  if (uploadMatch && req.method === 'POST') {
    const filename = req.headers['x-filename'] || url.searchParams.get('name') || 'upload.csv';
    try {
      const buf = await readBody(req, 64 * 1024 * 1024);
      const result = watchsync.importFile(uploadMatch[1], filename, buf);
      query.clearOrderCache();
      return sendJson(res, 200, { ok: true, file: result.saved, kind: result.kind, replaced: result.replaced, profiles: seenSummary() });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }

  const fileMatch = pathname.match(/^\/api\/seen\/([A-Za-z0-9._-]+)\/files\/(.+)$/);
  if (fileMatch && req.method === 'DELETE') {
    try {
      seen.deleteProfileFile(fileMatch[1], decodeURIComponent(fileMatch[2]));
      query.clearOrderCache();
      return sendJson(res, 200, { ok: true, profiles: seenSummary() });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }

  // Toggle one title in <profile>/Custom Server List.csv.
  const entryMatch = pathname.match(/^\/api\/seen\/([A-Za-z0-9._-]+)\/entry$/);
  if (entryMatch && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      const watchedId = body.imdbId || body.id;
      const result = seen.setCustomEntry(
        entryMatch[1],
        {
          imdbId: watchedId,
          name: body.name || '',
          year: body.year || '',
          type: body.type || 'movie',
        },
        body.watched === undefined ? null : Boolean(body.watched)
      );
      seen.setOverride('watched', watchedId, !result.watched);
      query.clearOrderCache();
      // One title, so it goes to TMDB right away instead of waiting for a sync.
      const tmdb = result.changed ? await watchsync.pushSingle(entryMatch[1] && (body.imdbId || body.id), result.watched) : { pushed: false };
      return sendJson(res, 200, { ok: true, ...result, tmdb, profiles: seenSummary() });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }

  if (entryMatch && req.method === 'GET') {
    const id = url.searchParams.get('imdbId') || '';
    const ids = seen.customIds(entryMatch[1]);
    return sendJson(res, 200, { watched: ids.has(id), total: ids.size });
  }

  // "I want to watch": the app's own watchlist, kept apart from watched.
  const wlEntryMatch = pathname.match(/^\/api\/seen\/([A-Za-z0-9._-]+)\/watchlist-entry$/);
  if (wlEntryMatch && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      const wantId = body.imdbId || body.id;
      const result = seen.setCustomWatchlistEntry(
        wlEntryMatch[1],
        { imdbId: wantId, name: body.name || '', year: body.year || '', type: body.type || 'movie' },
        body.onWatchlist === undefined ? null : Boolean(body.onWatchlist)
      );
      // Removing has to beat the read-only exports and the TMDB mirror too,
      // so it is recorded as an override; adding clears that record.
      seen.setOverride('watchlist', wantId, !result.watched);
      query.clearOrderCache();
      const tmdb = result.changed ? await watchsync.pushWatchlistSingle(body.imdbId || body.id, result.watched) : { pushed: false };
      return sendJson(res, 200, { ok: true, onWatchlist: result.watched, total: result.total, tmdb, profiles: seenSummary() });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }
  if (wlEntryMatch && req.method === 'GET') {
    const id = url.searchParams.get('imdbId') || '';
    const ids = seen.customWatchlistIds(wlEntryMatch[1]);
    return sendJson(res, 200, { onWatchlist: ids.has(id), total: ids.size });
  }

  // Red-flagged titles: a veto that never deletes anything.
  if (pathname === '/api/blocked' && req.method === 'GET') {
    return sendJson(res, 200, { items: store.listBlocked() });
  }
  if (pathname === '/api/blocked' && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      const out = store.setBlocked(body.imdbId || body.id, body.blocked === undefined ? true : Boolean(body.blocked), body);
      query.clearOrderCache();
      return sendJson(res, 200, { ok: true, ...out });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }

  if (pathname === '/api/imdb/test' && req.method === 'GET') {
    const id = url.searchParams.get('imdbId') || 'tt0111161';
    return sendJson(res, 200, await sources.testImdbExtras(id));
  }
  if (pathname === '/api/imdb/status' && req.method === 'GET') return sendJson(res, 200, sources.imdbStatus());

  const profileMatch = pathname.match(/^\/api\/seen\/([A-Za-z0-9._-]+)$/);
  if (profileMatch && req.method === 'POST') {
    fs.mkdirSync(seen.profileDir(profileMatch[1]), { recursive: true });
    seen.invalidateCache();
    return sendJson(res, 200, { ok: true, profiles: seenSummary() });
  }

  if (profileMatch && req.method === 'DELETE') {
    seen.deleteProfile(profileMatch[1]);
    query.clearOrderCache();
    return sendJson(res, 200, { ok: true, profiles: seenSummary() });
  }

  // Everything the movie card shows, assembled from the local index plus
  // whichever free sources are configured.
  const titleMatch = pathname.match(/^\/api\/title\/(tt\d+)$/);
  if (titleMatch && req.method === 'GET') {
    const id = titleMatch[1];
    const type = url.searchParams.get('type') === 'series' ? 'series' : 'movie';
    const profile = url.searchParams.get('profile') || '';

    let row = null;
    let genreNames = [];
    try {
      const index = imdb.loadIndex();
      const at = index.byId.get(id);
      if (at !== undefined) {
        row = index.rows[at];
        genreNames = row[4].map((g) => index.genreNames[g]).filter(Boolean);
      }
    } catch (_) {
      /* index may not be built yet — the card still works off Cinemeta */
    }

    const [meta, omdb] = await Promise.all([
      sources.cinemetaMeta(type, id).catch(() => null),
      settings.omdbKey ? sources.omdbLookup(settings.omdbKey, id).catch(() => null) : Promise.resolve(null),
    ]);

    let watched = false;
    if (profile) {
      try {
        watched = seen.customIds(profile).has(id);
      } catch (_) {
        watched = false;
      }
    }

    const splitList = (value) =>
      String(value || '')
        .split(',')
        .map((x) => x.trim())
        .filter(Boolean);

    const cinemetaDirector = meta && meta.director && meta.director.length ? meta.director : null;
    const cinemetaCast = meta && meta.cast && meta.cast.length ? meta.cast : null;

    return sendJson(res, 200, {
      id,
      type,
      name: (row && row[7]) || (meta && meta.name) || (omdb && omdb.title) || id,
      originalName: (row && row[8]) || '',
      year: (row && row[2]) || (meta && meta.year) || (omdb && omdb.year) || '',
      runtime: row && row[3] ? `${row[3]} min` : (meta && meta.runtime) || (omdb && omdb.runtime) || '',
      imdbRating: row ? (row[5] / 10).toFixed(1) : (meta && meta.imdbRating) || (omdb && omdb.imdbRating) || '',
      imdbVotes: row ? row[6] : omdb && omdb.imdbVotes ? Number(String(omdb.imdbVotes).replace(/[^0-9]/g, '')) : null,
      // what IMDb calls it (the "show … only" choices go by this)
      kind: row ? (TITLE_KIND_WORDS[row[1] & 0x0f] || '') + ((row[1] >> 4) & 1 ? ' · adult' : '') : '',
      genres: genreNames.length ? genreNames : (meta && meta.genres) || splitList(omdb && omdb.genre),
      country: (meta && meta.country) || (omdb && omdb.country) || '',
      director: cinemetaDirector || splitList(omdb && omdb.director),
      cast: cinemetaCast || splitList(omdb && omdb.actors),
      description: (meta && meta.description) || (omdb && omdb.plot) || '',
      poster: `https://images.metahub.space/poster/medium/${id}/img`,
      background: (meta && meta.background) || '',
      imdbUrl: `https://www.imdb.com/title/${id}/`,
      letterboxdUrl: sources.letterboxdUrl(id),
      omdb: omdb || null,
      awards: (meta && meta.awards) || (omdb && omdb.awards && omdb.awards !== 'N/A' ? omdb.awards : ''),
      imdbExtra: sources.cachedImdbExtra(id) || null,
      watched,
      onWatchlist: (() => {
        try {
          return query.seenSetsFor({ type: 'all', seenProfiles: [] }, imdb.loadIndex()).watchlist.has(id);
        } catch (_) {
          return profile ? seen.customWatchlistIds(profile).has(id) : false;
        }
      })(),
      blocked: store.blockedIds().has(id),
      profile,
    });
  }

  // The search box above the result: titles in the index, with their director.
  // Countries panel: titles per country (main / mentioned), from what's stored.
  if (pathname === '/api/countries/counts' && req.method === 'GET') {
    try {
      return sendJson(res, 200, query.countryCounts(imdb.loadIndex()));
    } catch (_) {
      return sendJson(res, 200, { main: {}, any: {}, known: 0, total: 0 });
    }
  }

  if (pathname === '/api/search/titles' && req.method === 'GET') {
    let index;
    try {
      index = imdb.loadIndex();
    } catch (_) {
      return sendJson(res, 200, { items: [], error: 'The IMDb index is not built yet.' });
    }
    const rows = imdb.searchTitles(index, url.searchParams.get('q') || '', util.clampInt(url.searchParams.get('n'), 1, 20, 10));
    const typeOf = (row) => (imdb.SERIES_KINDS.has(row[imdb.F.KIND] & 0x0f) ? 'series' : 'movie');
    // Directors come from Cinemeta (kept on disk); the ones not stored yet get ~2.5 s.
    const missing = rows.filter((r) => sources.cachedCinemeta(typeOf(r), r[imdb.F.ID]) === undefined);
    if (missing.length) {
      await Promise.race([
        Promise.all(missing.map((r) => sources.cinemetaMeta(typeOf(r), r[imdb.F.ID]).catch(() => null))),
        new Promise((ok) => setTimeout(ok, 2500)),
      ]);
    }
    const items = rows.map((row) => {
      const type = typeOf(row);
      const m = sources.cachedCinemeta(type, row[imdb.F.ID]);
      return {
        id: row[imdb.F.ID],
        type,
        name: row[imdb.F.NAME],
        original: row[imdb.F.ORIG] || '',
        year: row[imdb.F.YEAR] || '',
        imdbRating: (row[imdb.F.RATING10] / 10).toFixed(1),
        votes: row[imdb.F.VOTES],
        director: m && m.director ? m.director : [],
        poster: sources.imdbPosterUrl(row[imdb.F.ID]) || `https://images.metahub.space/poster/medium/${row[imdb.F.ID]}/img`,
      };
    });
    return sendJson(res, 200, { items });
  }

  /* ---------- Mostra planner ---------- */
  if (pathname === '/api/mostra/plan' && req.method === 'GET') {
    try {
      return sendJson(res, 200, await planner.view());
    } catch (err) {
      return sendJson(res, 200, { error: err.message, days: [] });
    }
  }
  if (pathname === '/api/mostra/plan' && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      if (body.clear) planner.clear();
      else if (body.remove) planner.remove(String(body.remove));
      else if (body.add) await planner.add(String(body.add));
      return sendJson(res, 200, await planner.view());
    } catch (err) {
      return sendJson(res, 200, { error: err.message, ...(await planner.view().catch(() => ({ days: [] }))) });
    }
  }
  if (pathname === '/api/mostra/programme' && req.method === 'GET') {
    try {
      // the films' IMDb ids come from the last linking (built in the background)
      if (imdb.indexExists()) mostra.linked(imdb.loadIndex(), settings).catch(() => {});
      return sendJson(res, 200, await planner.programme({ day: url.searchParams.get('day') || '', q: url.searchParams.get('q') || '', section: url.searchParams.get('section') || '' }));
    } catch (err) {
      return sendJson(res, 200, { error: err.message, films: [], days: [] });
    }
  }
  if (pathname === '/api/mostra/plan.ics' && req.method === 'GET') {
    try {
      const text = await planner.ics();
      setCors(res);
      res.writeHead(200, { 'Content-Type': 'text/calendar; charset=utf-8', 'Content-Disposition': 'attachment; filename="mostra-plan.ics"', 'Content-Length': Buffer.byteLength(text) });
      return res.end(text);
    } catch (err) {
      return sendText(res, 500, err.message);
    }
  }
  if (pathname === '/api/mostra/picked' && req.method === 'GET') return sendJson(res, 200, { keys: planner.pickedKeys() });

  /* ---------- Watchlist alerts (streaming on your services, in cinemas) ---------- */
  if (pathname === '/api/alerts' && req.method === 'GET') return sendJson(res, 200, alerts.status(settings));
  if (pathname === '/api/alerts/run' && req.method === 'POST') {
    alerts.run(settings, { reason: 'manual' }).catch(() => {});
    return sendJson(res, 200, alerts.status(settings));
  }
  if (pathname === '/api/alerts/seen' && req.method === 'POST') {
    const body = await readJsonBody(req).catch(() => ({}));
    alerts.markSeen(Array.isArray(body.keys) ? body.keys.map(String) : null);
    return sendJson(res, 200, alerts.status(settings));
  }
  if (pathname === '/api/alerts/services' && req.method === 'GET') return sendJson(res, 200, await alerts.serviceChoices(settings));
  if (pathname === '/api/alerts/services' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const patch = {};
    if (Array.isArray(body.ids)) patch.alertServices = body.ids.map(Number).filter(Number.isFinite).slice(0, 60);
    if (body.reset) patch.alertServices = null;
    if (typeof body.region === 'string' && /^[A-Za-z]{2}$/.test(body.region)) patch.alertRegion = body.region.toUpperCase();
    store.writeSettings(patch);
    const next = store.readSettings();
    return sendJson(res, 200, { ...(await alerts.serviceChoices(next)), status: alerts.status(next) });
  }

  /* ---------- Retrieve ratings for a list (the pop-up) ---------- */
  if ((pathname === '/api/retrieve/plan' || pathname === '/api/retrieve/start') && req.method === 'POST') {
    if (!imdb.indexExists()) return sendJson(res, 200, { error: 'The IMDb index has not been built yet.' });
    const body = await readJsonBody(req);
    const pl = store.normalizePlaylist(body.playlist || {});
    const opts = {
      sources: (Array.isArray(body.sources) ? body.sources : []).filter((x) => retrieve.SOURCES.includes(x)),
      scope: ['missing', 'unrated', 'older', 'all'].includes(body.scope) ? body.scope : 'unrated',
      days: util.clampInt(body.days, 1, 3650, 30),
      traktFilms: Boolean(body.traktFilms),
    };
    // The list as the page shows it; else this playlist's titles as it stands (before any Letterboxd re-rank).
    let ids = (Array.isArray(body.ids) ? body.ids : []).map(String).filter((x) => /^tt\d+$/.test(x)).slice(0, store.MAX_LIMIT);
    if (!ids.length) {
      const pick = { ...pl, lbRerank: false };
      if (query.lbOnly(pl) || pl.sortBy === 'letterboxd') pick.sortBy = 'weighted';
      for (const type of query.typesFor(pick)) {
        const scoped = pick.type === 'all' ? { ...pick, type } : pick;
        const r = await query.runQuery(scoped, settings, { limit: pick.limit, scanCap: Infinity, lookupCap: query.FULL_SCAN_LOOKUPS });
        for (const m of r.metas) ids.push(m.id);
      }
    }
    if (pathname === '/api/retrieve/plan') return sendJson(res, 200, { ...retrieve.plan(ids, opts, settings), status: retrieve.status() });
    if (!opts.sources.length) return sendJson(res, 200, { running: false, error: 'Pick at least one source.' });
    return sendJson(res, 200, retrieve.start(ids, opts, settings, { playlist: pl, label: pl.name }));
  }
  if (pathname === '/api/retrieve' && req.method === 'GET') {
    const since = url.searchParams.get('since');
    const st = retrieve.status({ since: since === null ? null : since });
    if (st.touched && st.touched.length) {
      // The rows as they now read, for the titles whose numbers changed. Past
      // ~400 at once they go in parts, whole versions at a time: this answer
      // covers the versions up to `version`, and `more` asks for the rest.
      let pairs = st.touched;
      if (pairs.length > 400) {
        const cut = pairs[399][1];
        pairs = pairs.filter(([, v]) => v <= cut);
        st.moves = (st.moves || []).filter(([v]) => v <= cut);
        st.more = cut < st.version;
        st.version = cut;
      }
      try {
        const index = imdb.loadIndex();
        const pl = retrieve.jobPlaylist() || store.blankPlaylist();
        st.metas = pairs.map(([id]) => {
          const row = retrieve.rowFor(id) || imdb.rowById(index, id);
          return row ? query.toMeta(row, pl, index) : null;
        }).filter(Boolean);
      } catch (_) {
        st.metas = [];
      }
    }
    delete st.touched;
    return sendJson(res, 200, st);
  }
  if (pathname === '/api/retrieve/stop' && req.method === 'POST') return sendJson(res, 200, { ok: retrieve.stop(), status: retrieve.status() });

  /* ---------- Sharing: updates for a friend's copy, data packs ---------- */
  if (pathname === '/api/app/status' && req.method === 'GET') {
    const dist = require('./lib/distribution');
    if (dist.local()) await dist.checkUpdate({ force: url.searchParams.get('check') === '1' }).catch(() => null);
    return sendJson(res, 200, { ...dist.updateStatus(), pendingImport: dist.pendingImport() });
  }
  if (pathname === '/api/app/update' && req.method === 'POST') {
    try {
      const applied = await require('./lib/distribution').applyUpdate();
      return sendJson(res, 200, { ok: true, applied });
    } catch (err) {
      return sendJson(res, 200, { ok: false, error: err.message });
    }
  }
  if (pathname === '/api/datapack/export' && req.method === 'GET') {
    const day = new Date().toISOString().slice(0, 10);
    res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Disposition': `attachment; filename="playlist-automator-datapack-${day}.zip"` });
    try {
      await require('./lib/distribution').exportPack(res);
    } catch (err) {
      console.error('[datapack]', err.message);
    }
    return res.end();
  }
  if (pathname === '/api/datapack/import' && req.method === 'POST') {
    const file = path.join(util.DIRS.DATA, 'datapack-upload.zip');
    try {
      await new Promise((ok, fail) => {
        const out = fs.createWriteStream(file);
        req.pipe(out);
        out.on('finish', ok);
        out.on('error', fail);
        req.on('error', fail);
      });
      const r = require('./lib/distribution').stageImport(file);
      return sendJson(res, 200, { ok: true, ...r, restart: true });
    } catch (err) {
      try { fs.rmSync(file, { force: true }); } catch (_) { /* nothing left */ }
      return sendJson(res, 200, { ok: false, error: err.message });
    }
  }

  /* ---------- Quick daily routine ---------- */
  if (pathname === '/api/daily' && req.method === 'GET') return sendJson(res, 200, daily.status());
  if (pathname === '/api/daily/run' && req.method === 'POST') {
    const body = await readJsonBody(req).catch(() => ({}));
    if (buildState.running) return sendJson(res, 200, { ...daily.status(), error: 'An IMDb download is already running — wait for it to finish.' });
    return sendJson(res, 200, daily.run({ reason: 'manual', publish: body.publish !== false }));
  }
  if (pathname === '/api/daily/stop' && req.method === 'POST') return sendJson(res, 200, { ok: daily.stop(), ...daily.status() });
  if (pathname === '/api/daily/settings' && req.method === 'POST') {
    const body = await readJsonBody(req);
    const patch = {};
    if (typeof body.auto === 'boolean') patch.dailyRoutineAuto = body.auto;
    if (Number.isInteger(body.hour) && body.hour >= 0 && body.hour <= 23) patch.dailyRoutineHour = body.hour;
    store.writeSettings(patch);
    return sendJson(res, 200, daily.status());
  }

  /* ---------- Fresh IMDb ratings (daily, for new / in cinemas / festival titles) ---------- */
  if (pathname === '/api/fresh' && req.method === 'GET') return sendJson(res, 200, fresh.status());
  if (pathname === '/api/fresh/run' && req.method === 'POST') {
    if (!imdb.indexExists()) return sendJson(res, 200, { ...fresh.status(), error: 'The IMDb index has not been built yet.' });
    fresh.run(settings, { reason: 'manual' });
    return sendJson(res, 200, fresh.status());
  }
  if (pathname === '/api/fresh/stop' && req.method === 'POST') {
    fresh.stop();
    return sendJson(res, 200, fresh.status());
  }

  // "Data health": what's missing in the stored data, per kind of title.
  if (pathname === '/api/audit' && req.method === 'GET') {
    try {
      return sendJson(res, 200, query.auditData(imdb.loadIndex(), settings));
    } catch (err) {
      return sendJson(res, 200, { error: err.message });
    }
  }

  // Data health → Fix one gap (a background lookup, like "Populate").
  if (pathname === '/api/audit/fix' && req.method === 'POST') {
    if (!imdb.indexExists()) return sendJson(res, 200, { running: false, error: 'The IMDb index has not been built yet.' });
    const body = await readJsonBody(req);
    const group = String(body.group || '');
    const gap = String(body.gap || '');
    if (!query.KIND_GROUPS[group] || !query.GAPS[gap]) return sendJson(res, 200, { running: false, error: 'Unknown gap.' });
    const blocked = query.fixBlocked(gap, settings);
    if (blocked) return sendJson(res, 200, { running: false, error: blocked });
    const st = scanjobs.populateStatus();
    if (st.running) return sendJson(res, 200, { ...st, busy: true, error: 'Another lookup is running (' + (st.label || st.mode || 'Populate') + '). Stop it first, or wait for it to finish.' });
    return sendJson(res, 200, scanjobs.startPopulate(settings, { mode: 'fix', group, gap }));
  }

  // A title's numbers changed: its new place in the list on screen (and its row as it now reads).
  if (pathname === '/api/rerank' && req.method === 'POST') {
    const body = await readJsonBody(req);
    try {
      const index = imdb.loadIndex();
      const playlist = store.normalizePlaylist(body.playlist || {});
      const ids = (Array.isArray(body.ids) ? body.ids : []).map(String);
      const id = String(body.id || '');
      const out = query.repositionOne(playlist, index, ids, id);
      if (out.to !== out.from) scanjobs.moveInScans(playlist, settings, (list) => query.repositionOne(playlist, index, list, id).ids);
      const row = imdb.rowById(index, id);
      const meta = row ? query.toMeta(row, playlist, index) : null;
      return sendJson(res, 200, { ids: out.ids, from: out.from, to: out.to, meta });
    } catch (err) {
      return sendJson(res, 200, { error: err.message });
    }
  }

  // Every rating the app knows for one title (the card's ratings strip); POST …/refresh re-reads one source now.
  const ratingsMatch = pathname.match(/^\/api\/title\/(tt\d+)\/ratings(\/refresh)?$/);
  if (ratingsMatch && (req.method === 'GET' || (ratingsMatch[2] && req.method === 'POST'))) {
    const id = ratingsMatch[1];
    let row = null;
    let index = null;
    try {
      index = imdb.loadIndex();
      row = imdb.rowById(index, id);
    } catch (_) {
      /* no index: what the sources have */
    }
    const isSeries = row ? imdb.SERIES_KINDS.has(row[imdb.F.KIND] & 0x0f) : url.searchParams.get('type') === 'series';
    const traktKind = isSeries ? 'show' : 'movie';
    let error = '';
    let changed = false; // something the list's order depends on moved
    let cardChanges = [];
    if (ratingsMatch[2]) {
      const body = await readJsonBody(req);
      const src = String(body.src || '');
      try {
        if (src === 'imdb' || src === 'metascore') await sources.imdbLive(id);
        else if (src === 'letterboxd') {
          const r = await sources.letterboxdRating(id, { force: true, histogram: true });
          if (r === undefined) error = 'Letterboxd did not answer — ' + ((sources.letterboxdHealth() || {}).message || 'try again in a moment') + '.';
        } else if (src === 'tmdb') {
          if (!settings.tmdbKey) error = 'No TMDB key saved (Settings).';
          else {
            const r = await sources.tmdbFind(settings.tmdbKey, id, { force: true });
            if (r && r.error) error = 'TMDB: ' + r.error;
          }
        } else if (src === 'trakt') {
          if (!settings.traktClientId) error = 'No Trakt Client ID saved (Settings).';
          else if ((await sources.traktRating(settings.traktClientId, id, { force: true, kind: traktKind })) === undefined) error = 'Trakt did not answer.';
        } else if (src === 'omdb') {
          if (!settings.omdbKey) error = 'No OMDb key saved (Settings).';
          else if ((await sources.omdbLookup(settings.omdbKey, id, { force: true })) === undefined) error = 'OMDb did not answer.';
        } else error = 'Unknown source.';
      } catch (err) {
        error = err.message;
      }
      if (!error && src !== 'omdb' && src !== 'metascore') {
        changed = true;
        query.clearOrderCache();
      }
    } else if (url.searchParams.get('fill') === '1') {
      // Opening the card retrieves this title's ratings the way "Retrieve ratings" does a list:
      // IMDb's live numbers every 6 hours, the others when there's no rating yet or it's a month old.
      try {
        const r = await Promise.race([
          retrieve.retrieveTitle(id, settings, { type: isSeries ? 'series' : 'movie' }),
          new Promise((ok) => setTimeout(() => ok(null), 15000)),
        ]);
        if (r) {
          changed = r.changed;
          cardChanges = r.changes;
        }
      } catch (_) {
        /* the card shows what is stored */
      }
      // IMDb extras the strip shows (written reviews, Metascore), when never fetched.
      const ex0 = sources.cachedImdbExtra(id);
      if (!ex0 || !(ex0.have || []).includes('reviews') || !(ex0.have || []).includes('meta')) {
        await Promise.race([sources.imdbExtraBatch([id], { need: ['reviews', 'meta'] }).catch(() => null), new Promise((ok) => setTimeout(ok, 6000))]);
      }
      if (changed) query.clearOrderCache();
    }
    const ago = (ms) => (Number.isFinite(ms) ? Date.now() - ms : null);
    const items = [];
    const ex = sources.cachedImdbExtra(id) || {};
    const lv = sources.liveOf(id);
    const live = Boolean(lv && (!index || lv.at > (index.builtAt || 0)));
    const row2 = index ? imdb.rowById(index, id) : null;
    const liveRated = live && typeof lv.rating === 'number' && lv.votes > 0;
    items.push({
      src: 'imdb',
      label: 'IMDb',
      rating: liveRated ? lv.rating.toFixed(1) : row2 && row2[imdb.F.VOTES] ? (row2[imdb.F.RATING10] / 10).toFixed(1) : '',
      scale: 10,
      votes: liveRated ? lv.votes : row2 ? row2[imdb.F.VOTES] : null,
      reviews: typeof ex.reviewTotal === 'number' ? ex.reviewTotal : null,
      reviewsLabel: 'written reviews',
      empty: live ? 'no rating yet' : 'not rated yet',
      at: live ? lv.at : index ? index.builtAt || null : null,
      note: live ? 'read from IMDb' : 'IMDb dataset',
    });
    const lb = sources.cachedLetterboxdRating(id);
    const st = sources.lbState(id);
    items.push({
      src: 'letterboxd',
      label: 'Letterboxd',
      rating: lb && lb.rating ? Number(lb.rating).toFixed(2) : lb && lb.raw && lb.raw.n ? Number(lb.raw.avg).toFixed(2) : '',
      scale: 5,
      votes: lb ? (lb.rating ? lb.ratingCount : lb.raw ? lb.raw.n : lb.ratingCount) : null,
      reviews: lb && typeof lb.reviewCount === 'number' ? lb.reviewCount : null,
      reviewsLabel: 'reviews',
      state: st,
      empty: st === 'nopage' ? 'no page' : st === 'novotes' ? 'nobody rated it' : st === 'few' && !(lb && lb.raw && lb.raw.n) ? 'a few ratings, not counted' : st === 'unknown' ? 'not read yet' : '',
      few: Boolean(lb && !lb.rating && lb.raw && lb.raw.n),
      at: ago(sources.letterboxdAge(id)),
    });
    const tf = sources.cachedTmdbFind(id);
    items.push({
      src: 'tmdb',
      label: 'TMDB',
      rating: tf && tf.found && tf.voteCount ? Number(tf.voteAverage).toFixed(1) : '',
      scale: 10,
      votes: tf && tf.found ? tf.voteCount : null,
      empty: !settings.tmdbKey ? 'no key saved' : tf === undefined ? 'not read yet' : !tf.found ? 'not on TMDB' : !tf.voteCount ? 'no votes' : '',
      at: ago(sources.tmdbFindAge(id)),
    });
    const tr = sources.cachedTrakt(id, traktKind);
    items.push({
      src: 'trakt',
      label: 'Trakt',
      rating: tr && tr.found && tr.votes ? Number(tr.rating).toFixed(1) : '',
      scale: 10,
      votes: tr && tr.found ? tr.votes : null,
      empty: !settings.traktClientId ? 'no Client ID saved' : tr === undefined ? 'not read yet' : !tr.found ? 'not on Trakt' : !tr.votes ? 'no votes' : '',
      at: ago(sources.traktAge(id, traktKind)),
    });
    const om = sources.cachedOmdb(id);
    const omdbR = (name) => (om && Array.isArray(om.ratings) ? (om.ratings.find((r) => r.Source === name) || {}).Value || '' : '');
    const meta = typeof ex.metascore === 'number' ? ex.metascore : om && om.metascore && om.metascore !== 'N/A' ? Number(om.metascore) : null;
    items.push({
      src: 'metascore',
      label: 'Metascore',
      rating: meta !== null && meta !== undefined ? String(meta) : '',
      scale: 100,
      empty: 'none',
      at: ago(sources.imdbExtraAge(id)),
    });
    if (settings.omdbKey || om) {
      const rt = omdbR('Rotten Tomatoes');
      items.push({
        src: 'omdb',
        label: 'Rotten Tomatoes',
        rating: rt,
        scale: 0,
        empty: !settings.omdbKey ? 'no OMDb key' : om === undefined ? 'not read yet' : 'none',
        at: ago(sources.cachedOmdbAge(id)),
      });
    }
    sources.flushAll();
    return sendJson(res, 200, { id, items, error, changed, changes: cardChanges });
  }

  // Posters for the page: fetched once from where the list points (Metahub / TMDB), then served from disk.
  const posterMatch = pathname.match(/^\/api\/poster\/(tt\d+)$/);
  if (posterMatch && req.method === 'GET') {
    const id = posterMatch[1];
    const src = String(url.searchParams.get('src') || '');
    const dir = path.join(util.DIRS.CACHE, 'posters');
    // One copy per title AND image address: a title that moves to a new poster (IMDb's instead of Metahub's) gets the new one.
    const file = path.join(dir, id + '-' + util.sha1(src).slice(0, 10) + '.img');
    const refresh = url.searchParams.get('refresh') === '1';
    try {
      if (refresh || !fs.existsSync(file)) {
        if (!/^https:\/\/(images\.metahub\.space|image\.tmdb\.org|m\.media-amazon\.com)\//.test(src)) return sendJson(res, 400, { error: 'poster source not allowed' });
        const r = await fetch(src, { signal: AbortSignal.timeout(15000) });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const buf = Buffer.from(await r.arrayBuffer());
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(file, buf);
        fs.writeFileSync(file + '.type', r.headers.get('content-type') || 'image/jpeg');
      }
      const body = fs.readFileSync(file);
      let type = 'image/jpeg';
      try { type = fs.readFileSync(file + '.type', 'utf8') || type; } catch (_) { /* default */ }
      res.writeHead(200, { 'Content-Type': type, 'Content-Length': body.length, 'Cache-Control': 'public, max-age=604800' });
      return res.end(body);
    } catch (err) {
      res.writeHead(302, { Location: src || 'about:blank' }); // couldn't keep a copy: the original still works
      return res.end();
    }
  }

  /* ---------- Cinemas, the Mostra, festivals, and checking matches ---------- */
  const cinemaMatch = pathname.match(/^\/api\/title\/(tt\d+)\/cinemas$/);
  if (cinemaMatch && req.method === 'GET') {
    const e = screenings.entriesOf(cinemaMatch[1]);
    // how each source title was matched (so the card can offer "Wrong match?")
    for (const x of e.entries) x.matches = (x.keys || []).map((k) => { const r = matches.get(k); return r ? { key: k, status: r.status } : { key: k, status: 'old' }; });
    return sendJson(res, 200, { ...e, mark: screenings.markOf(cinemaMatch[1]), status: screenings.status() });
  }
  if (pathname === '/api/cinemas/status' && req.method === 'GET') {
    return sendJson(res, 200, screenings.status());
  }
  if (pathname === '/api/cinemas/refresh' && req.method === 'POST') {
    return sendJson(res, 200, await screenings.ensureFresh(settings, { wait: true, force: true }));
  }
  if (pathname === '/api/festival/mostra' && req.method === 'GET') {
    return sendJson(res, 200, await mostra.summary());
  }
  if (pathname === '/api/festivals' && req.method === 'GET') {
    try {
      return sendJson(res, 200, await festivals.upcoming({ force: url.searchParams.get('reload') === '1' }));
    } catch (err) {
      return sendJson(res, 200, { festivals: [], error: err.message });
    }
  }
  if (pathname === '/api/matches/review' && req.method === 'GET') {
    const only = String(url.searchParams.get('only') || '');
    const include = only ? only.split(',').filter((x) => ['unsure', 'likely', 'none'].includes(x)) : ['unsure', 'likely', 'none'];
    const items = matches.reviewList({ include });
    const counts = { unsure: 0, likely: 0, none: 0 };
    for (const r of matches.reviewList()) counts[r.status] += 1;
    return sendJson(res, 200, { counts, items: items.slice(0, 500) });
  }
  if (pathname === '/api/matches/for' && req.method === 'GET') {
    const keys = String(url.searchParams.get('keys') || '').split(',').filter(Boolean).slice(0, 20);
    const id = String(url.searchParams.get('id') || '');
    // A cinema match made before matches were kept: record it now (as found), so it can be corrected.
    if (/^tt\d+$/.test(id)) {
      for (const e of screenings.entriesOf(id).entries) {
        for (const k of e.keys || []) {
          if (keys.includes(k) && !matches.get(k) && e.info) {
            const index = imdb.loadIndex();
            const at = index.byId.get(id);
            const row = at !== undefined ? index.rows[at] : null;
            matches.note(k, e.info, id, 'sure', { imdbId: id, title: row ? row[imdb.F.NAME] : id, originalTitle: row ? row[imdb.F.ORIG] : '', year: row ? row[imdb.F.YEAR] : 0, runtime: row ? row[imdb.F.RUNTIME] : 0, votes: row ? row[imdb.F.VOTES] : 0, rating: row && row[imdb.F.RATING10] ? row[imdb.F.RATING10] / 10 : null });
          }
        }
      }
    }
    return sendJson(res, 200, { items: keys.map((k) => matches.get(k)).filter(Boolean) });
  }
  if (pathname === '/api/matches/decide' && req.method === 'POST') {
    const body = await readJsonBody(req);
    if (!body.key) return sendJson(res, 400, { error: 'key missing' });
    const rec = body.undo ? (matches.forget(body.key), null) : matches.decide(String(body.key), body.imdbId ? String(body.imdbId) : null);
    query.clearOrderCache();
    screenings.ensureFresh(settings, { force: true }).catch(() => {}); // the marks follow your pick
    return sendJson(res, 200, { ok: true, rec });
  }
  if (pathname === '/api/matches/search' && req.method === 'GET') {
    const q = String(url.searchParams.get('q') || '').trim();
    if (!q) return sendJson(res, 200, { items: [] });
    // A pasted IMDb link or id: that title, straight from the index.
    const tt = (q.match(/tt\d{5,}/) || [])[0];
    if (tt) {
      const index = imdb.loadIndex();
      const at = index.byId.get(tt);
      const row = at !== undefined ? index.rows[at] : null;
      return sendJson(res, 200, { items: [{ imdbId: tt, title: row ? row[imdb.F.NAME] : tt, originalTitle: row ? row[imdb.F.ORIG] : '', year: row ? row[imdb.F.YEAR] : 0, votes: row ? row[imdb.F.VOTES] : 0, rating: row && row[imdb.F.RATING10] ? row[imdb.F.RATING10] / 10 : null, from: row ? 'imdb' : 'link' }] });
    }
    try {
      const items = await matches.search(imdb.loadIndex(), settings, q, url.searchParams.get('year'));
      return sendJson(res, 200, { items: items.slice(0, 12) });
    } catch (err) {
      return sendJson(res, 200, { items: [], error: err.message });
    }
  }

  const reviewMatch = pathname.match(/^\/api\/title\/(tt\d+)\/reviews$/);
  if (reviewMatch && req.method === 'GET') {
    const force = url.searchParams.get('reload') === '1';
    const want = util.clampInt(url.searchParams.get('n'), 1, 10, 3);
    try {
      const id = reviewMatch[1];
      const out = await sources.titleReviews(id, { force, want });
      // Series: Letterboxd when it has them; TMDB and Trakt alongside (looked up now if not stored).
      try {
        const index = imdb.loadIndex();
        const i = index.byId.get(id);
        const row = i !== undefined ? index.rows[i] : null;
        if (row && imdb.SERIES_KINDS.has(row[imdb.F.KIND] & 0x0f)) {
          const jobs = [];
          if (settings.tmdbKey && (force || sources.cachedTmdbFind(id) === undefined)) jobs.push(sources.tmdbFind(settings.tmdbKey, id, { force }).catch(() => null));
          if (settings.traktClientId && (force || sources.cachedTrakt(id) === undefined)) jobs.push(sources.traktRating(settings.traktClientId, id, { force }).catch(() => null));
          await Promise.all(jobs);
          const c = query.seriesConsensus(row);
          const sec = query.seriesSecond(row);
          out.series = {
            parts: sec ? sec.parts.map((p) => ({ src: p.src, rating: p.rating, n: p.n })) : [],
            listed: Boolean(sec && sec.listed),
            consensus: c ? Math.round(c.rating * 10) / 10 : null,
          };
        }
      } catch (_) {
        /* the card still shows the reviews */
      }
      return sendJson(res, 200, out);
    } catch (err) {
      return sendJson(res, 200, { imdb: { reviews: [], error: err.message }, letterboxd: { reviews: [], error: err.message } });
    }
  }

  return sendJson(res, 404, { error: 'Unknown API route.' });
}

/* ------------------------------------------------------------------ *
 * Stremio add-on routes
 * ------------------------------------------------------------------ */

// Catalog content must never be served from a cache: editing a playlist's
// filters is supposed to change what Stremio shows the next time it asks.
const NO_CACHE = { 'Cache-Control': 'no-cache, no-store, must-revalidate', Pragma: 'no-cache', Expires: '0' };

/** Install links are built here, so the page never assembles protocol URLs itself. */
function withUrls(list, settings) {
  const host = `127.0.0.1:${settings.port}`;
  return list.map((p) => {
    const u = urlsFor(settings, `p/${p.slug}/manifest.json`, addon.installUrls(p, { host }), hasCombos(p));
    const n = store.normalizePlaylist(p);
    return {
      ...p,
      installUrl: u.stremio,
      manifestUrl: u.http,
      check: scanjobs.checkState(p),
      dynamic: releases.isDynamic(p),
      // what shapes this list in Stremio, at a glance
      versions: store.versionsOf(p),
      part: (settings.publishBundleParts || {})[p.slug] || null,
      description: store.describePlaylist(n),
      limit: n.limit,
    };
  });
}

/** A plain, script-free status page for the popup windows. */
function plainPage(title, message) {
  const esc = (t) => String(t).replace(/[<>&"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;' })[c]);
  return `<!doctype html><meta charset="utf-8"><title>${esc(title)}</title>` +
    `<body style="font:16px system-ui;background:#0f1422;color:#e6e9f2;padding:40px"><h3>${esc(title)}</h3><p>${esc(message)}</p></body>`;
}

/** Which installs Stremio is holding an outdated manifest for. */
function installState(settings) {
  const hashes = settings.installedHashes || {};
  const base = `http://127.0.0.1:${settings.port}`;
  const out = { playlists: {}, bundle: null };
  for (const pl of store.listPlaylists()) {
    const now = addon.manifestHash(addon.buildManifest(pl, { baseUrl: base }));
    out.playlists[pl.slug] = hashes[pl.slug] ? (hashes[pl.slug] === now ? 'current' : 'stale') : 'unknown';
  }
  if (hashes.__all) out.bundle = hashes.__all === addon.manifestHash(addon.buildBundleManifest({ baseUrl: base })) ? 'current' : 'stale';
  return out;
}

async function serveCatalog(res, playlist, type, extraSegment, settings, label) {
  if (!query.typesFor(playlist).includes(type)) return sendJson(res, 200, { metas: [] }, NO_CACHE);
  const extra = addon.parseExtra(extraSegment);
  const skip = parseInt(extra.skip, 10) || 0;
  try {
    const scoped = playlist.type === 'all' ? { ...playlist, type } : playlist;
    const result = await query.runQuery(scoped, settings, {
      skip,
      limit: 100,
      search: extra.search || '',
      genreOverride: extra.genre || '',
      // Every candidate, like the builder page: a rare country can sit
      // anywhere in 200,000 titles. Looked-up titles cost nothing.
      scanCap: Infinity,
      lookupCap: query.FULL_SCAN_LOOKUPS,
    });
    if (result.diagnostics.error) console.error(`[catalog] ${label}: ${result.diagnostics.error}`);
    return sendJson(res, 200, { metas: result.metas }, NO_CACHE);
  } catch (err) {
    console.error(`[catalog] ${label} failed:`, err.message);
    return sendJson(res, 200, { metas: [] }, NO_CACHE);
  }
}

/** /all/... — every playlist as one add-on, catalogs keyed by slug. */
async function handleBundle(req, res, pathname) {
  const settings = store.readSettings();
  const parts = pathname.split('/').filter(Boolean); // ['all', ...]
  const rest = parts.slice(1);
  if (rest[0] === 'configure') {
    setCors(res);
    res.writeHead(302, { Location: '/' });
    return res.end();
  }
  if (rest[0] === 'manifest.json') {
    return sendJson(res, 200, addon.buildBundleManifest({ baseUrl: `http://127.0.0.1:${settings.port}` }), NO_CACHE);
  }
  if (rest[0] === 'catalog' && rest.length >= 3) {
    const type = rest[1];
    const slug = (rest.length >= 4 ? rest[2] : rest[2].replace(/\.json$/, '')).replace(/[^a-z0-9-]/g, '');
    const extraSegment = rest.length >= 4 ? rest[3].replace(/\.json$/, '') : '';
    const playlist = slug ? store.getPlaylist(slug) : null;
    if (!playlist) return sendJson(res, 200, { metas: [] }, NO_CACHE);
    return serveCatalog(res, playlist, type, extraSegment, settings, `all/${slug}`);
  }
  return sendJson(res, 404, { err: 'Unsupported resource.' });
}

async function handleAddon(req, res, pathname) {
  const settings = store.readSettings();
  const host = `127.0.0.1:${settings.port}`;

  const parts = pathname.split('/').filter(Boolean); // ['p', slug, ...]
  const slug = parts[1];
  const playlist = store.getPlaylist(slug);

  if (!playlist) {
    return sendJson(res, 404, { err: 'No playlist with that id. It may have been deleted on the setup page.' });
  }

  const rest = parts.slice(2);

  if (rest[0] === 'configure') {
    setCors(res);
    res.writeHead(302, { Location: `/?edit=${encodeURIComponent(slug)}` });
    return res.end();
  }

  if (rest[0] === 'manifest.json') {
    const manifest = addon.buildManifest(playlist, { baseUrl: `http://${host}` });
    return sendJson(res, 200, manifest, NO_CACHE);
  }

  if (rest[0] === 'catalog') {
    const type = rest[1];
    const catalogId = (rest.length >= 4 ? rest[2] : String(rest[2] || '').replace(/\.json$/, ''));
    const extraSegment = rest.length >= 4 ? rest[3].replace(/\.json$/, '') : '';
    if (catalogId !== addon.CATALOG_ID) return sendJson(res, 200, { metas: [] }, NO_CACHE);
    return serveCatalog(res, playlist, type, extraSegment, settings, slug);
  }

  return sendJson(res, 404, { err: 'Unsupported resource.' });
}

/* ------------------------------------------------------------------ *
 * Router
 * ------------------------------------------------------------------ */

async function router(req, res) {
  const url = new URL(req.url, 'http://127.0.0.1');
  const pathname = decodeURIComponent(url.pathname);

  if (req.method === 'OPTIONS') {
    setCors(res);
    res.writeHead(204);
    return res.end();
  }

  if (pathname === '/' || pathname === '/index.html' || pathname === '/configure') {
    const file = path.join(DIRS.WEB, 'index.html');
    let html;
    try {
      html = fs.readFileSync(file, 'utf8');
    } catch (_) {
      return sendText(res, 500, 'src/web/index.html is missing from the install folder.');
    }
    return sendText(res, 200, html, 'text/html; charset=utf-8');
  }

  const logoMatch = pathname.match(/^\/logo\/([a-z0-9-]+)\.png$/);
  if (logoMatch) {
    const png = util.playlistIconPng(logoMatch[1]);
    setCors(res);
    res.writeHead(200, {
      'Content-Type': 'image/png',
      'Content-Length': png.length,
      'Cache-Control': 'max-age=86400',
    });
    return res.end(png);
  }

  if (pathname === '/favicon.ico') {
    const png = util.playlistIconPng('playlistomatic');
    res.writeHead(200, { 'Content-Type': 'image/png', 'Content-Length': png.length });
    return res.end(png);
  }

  if (pathname.startsWith('/api/')) {
    try {
      return await handleApi(req, res, pathname, url);
    } catch (err) {
      console.error('[api]', pathname, err.message);
      return sendJson(res, 500, { error: err.message });
    }
  }

  // Popups open these local pages; the server forwards to the real site, so
  // the builder page itself never redirects windows to third-party URLs.
  if (pathname === '/go/tmdb-link') {
    const st = store.readSettings();
    try {
      const link = await watchsync.startLink(`http://127.0.0.1:${st.port}/tmdb/callback`);
      res.writeHead(302, { Location: link.approveUrl });
      return res.end();
    } catch (err) {
      return sendText(res, 200, plainPage('Could not start TMDB linking', err.message), 'text/html; charset=utf-8');
    }
  }
  const goExport = pathname.match(/^\/go\/export\/(letterboxd|imdb)$/);
  if (goExport) {
    res.writeHead(302, { Location: goExport[1] === 'letterboxd' ? 'https://letterboxd.com/user/exportdata/' : 'https://www.imdb.com/list/ratings' });
    return res.end();
  }

  if (pathname === '/tmdb/callback') {
    // TMDB sends the browser here after approval; the builder page notices
    // the linked account on its own.
    try {
      await watchsync.finishLink(url.searchParams.get('request_token') || '');
      return sendText(res, 200, plainPage('TMDB account linked', 'You can close this window and go back to the builder page.'), 'text/html; charset=utf-8');
    } catch (err) {
      return sendText(res, 200, plainPage('Could not link TMDB', err.message), 'text/html; charset=utf-8');
    }
  }

  if (pathname.startsWith('/all/')) {
    try {
      return await handleBundle(req, res, pathname);
    } catch (err) {
      console.error('[bundle]', err.message);
      return sendJson(res, 500, { err: err.message });
    }
  }

  if (pathname.startsWith('/p/')) {
    try {
      return await handleAddon(req, res, pathname);
    } catch (err) {
      console.error('[addon]', pathname, err.message);
      return sendJson(res, 500, { err: err.message });
    }
  }

  return sendText(res, 404, 'Not found.');
}

/* ------------------------------------------------------------------ *
 * Start / CLI
 * ------------------------------------------------------------------ */

function openBrowser(url) {
  execFile('cmd', ['/c', 'start', '""', url], (err) => {
    if (err) console.log(`   (could not open the browser automatically — go to ${url})`);
  });
}

function listen(server, port) {
  return new Promise((resolve, reject) => {
    const onError = (err) => {
      server.removeListener('listening', onListening);
      reject(err);
    };
    const onListening = () => {
      server.removeListener('error', onError);
      resolve(port);
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(port, '127.0.0.1');
  });
}

async function serve() {
  const settings = store.readSettings();
  const server = http.createServer((req, res) => {
    router(req, res).catch((err) => {
      console.error('[router]', err);
      try {
        sendText(res, 500, 'Internal error.');
      } catch (_) {
        /* response already sent */
      }
    });
  });

  // Publishing waits for a click unless automatic publishing was switched on
  // after this change (it used to be on unless switched off).
  if (!settings.publishAutoOptIn) {
    store.writeSettings({ publishAuto: false, publishAutoOptIn: true });
    settings.publishAuto = false;
  }
  try {
    const n = store.migrateSubListsDefault();
    if (n) console.log(`Sub-lists: ${n} playlist(s) switched to "by year" (the new default).`);
  } catch (err) {
    console.warn('Sub-list default switch skipped:', err.message);
  }
  try {
    const names = store.migrateLbVettingAuto();
    if (names.length) console.log(`"Require a Letterboxd page" switched off in ${names.length} playlist(s) where a Letterboxd option had turned it on: ${names.join(', ')}`);
  } catch (err) {
    console.warn('Letterboxd requirement clean-up skipped:', err.message);
  }

  sources.setLetterboxdEnabled(store.serviceEnabled('letterboxd'));
  sources.setLetterboxdHistograms(Boolean(settings.lbHistograms));
  sources.setLetterboxdWindowMode(settings.lbWindow !== false);
  // Check every outside service in the background: the page asks for the
  // result when it opens and shows Settings if anything switched on fails.
  setTimeout(() => updateWorkerIfOutdated().catch(() => {}).then(() => connections.checkAll()).catch(() => {}), 1500);
  setTimeout(dailyRefreshTick, 60 * 1000);
  setInterval(dailyRefreshTick, 30 * 60 * 1000);
  // "In cinemas": your city's cinemas and the Mostra, rebuilt in the background every few hours.
  setTimeout(() => screenings.ensureFresh(store.readSettings()).catch(() => {}), 20 * 1000);
  setInterval(() => screenings.ensureFresh(store.readSettings()).catch(() => {}), 60 * 60 * 1000);
  // Watchlist alerts: a few minutes after starting, then every 6 hours.
  setTimeout(() => alerts.tick(store.readSettings()), 3 * 60 * 1000);
  setInterval(() => alerts.tick(store.readSettings()), 30 * 60 * 1000);
  // Fresh IMDb ratings for new, in-cinema and festival titles: once a day (from 04:00).
  setTimeout(() => fresh.tick(store.readSettings()), 5 * 60 * 1000);
  setInterval(() => fresh.tick(store.readSettings()), 15 * 60 * 1000);
  // The quick daily routine (when switched on in its window): every day at its hour.
  daily.init({ startBuild, buildState, runPublish });
  setInterval(() => daily.tick(), 10 * 60 * 1000);

  let port = settings.port;
  const existing = store.listPlaylists();

  try {
    await listen(server, port);
  } catch (err) {
    if (err.code !== 'EADDRINUSE') throw err;

    // (a copy's very first start: its example playlists aren't installed anywhere yet)
    if (existing.length && !require('./lib/distribution').isFirstRun()) {
      console.error('');
      console.error(`  Port ${port} is busy, and you already have ${existing.length} playlist(s) installed on it.`);
      console.error('  Free that port (another copy of this app is probably already running — check your browser');
      console.error(`  at http://127.0.0.1:${port} first), or change "port" in data/settings.json and reinstall`);
      console.error('  your playlists in Stremio, since the port is part of every add-on URL.');
      console.error('');
      process.exit(1);
    }

    let found = 0;
    for (let candidate = port + 1; candidate <= port + 20; candidate += 1) {
      try {
        await listen(server, candidate);
        found = candidate;
        break;
      } catch (inner) {
        if (inner.code !== 'EADDRINUSE') throw inner;
      }
    }
    if (!found) throw new Error(`No free port between ${port} and ${port + 20}.`);
    port = found;
    store.writeSettings({ port });
    console.log(`  Port ${settings.port} was busy — using ${port} instead and saving that choice.`);
  }

  const home = `http://127.0.0.1:${port}`;
  const index = imdb.indexStat();

  console.log('');
  console.log('  Stremio Playlist Automator');
  console.log('  ──────────────────────────');
  console.log(`  Builder page   ${home}`);
  console.log(`  Node           v${process.versions.node}`);
  console.log(`  IMDb index     ${index.exists ? `${(index.bytes / 1048576).toFixed(0)} MB on disk` : 'not built yet — build it from the page'}`);
  console.log(`  Playlists      ${existing.length}`);
  console.log(`  TMDB key       ${settings.tmdbKey ? 'configured' : 'not set (streaming-service filter is off)'}`);
  console.log('');
  console.log('  Leave this window open while you use Stremio. Ctrl+C to stop.');
  console.log('');

  if (settings.openBrowser) openBrowser(home);
}

async function doctor() {
  const settings = store.readSettings();
  const lines = [];
  lines.push(['Node.js', `v${process.versions.node}`, NODE_MAJOR >= 18 ? 'ok' : 'too old']);
  lines.push(['Data folder', DIRS.DATA, fs.existsSync(DIRS.DATA) ? 'ok' : 'missing']);

  const stat = imdb.indexStat();
  lines.push([
    'IMDb index',
    stat.exists ? `${(stat.bytes / 1048576).toFixed(0)} MB` : 'not built',
    stat.exists ? 'ok' : 'run: npm run build-index',
  ]);

  if (stat.exists) {
    try {
      const index = imdb.loadIndex();
      lines.push(['Titles indexed', index.count.toLocaleString('en-US'), 'ok']);
      lines.push(['Vote floor', String(index.minVotes), 'ok']);
    } catch (err) {
      lines.push(['Index load', err.message, 'rebuild it']);
    }
  }

  lines.push(['Playlists', String(store.listPlaylists().length), 'ok']);
  lines.push(['TMDB key', settings.tmdbKey ? util.hideSecrets('set') : 'not set', settings.tmdbKey ? 'ok' : 'optional']);

  if (settings.tmdbKey) {
    const check = await sources.verifyKey(settings.tmdbKey);
    lines.push(['TMDB reachable', check.message, check.ok ? 'ok' : 'failed']);
  }

  try {
    const res = await fetch('https://v3-cinemeta.strem.io/meta/movie/tt1254207.json');
    lines.push(['Cinemeta reachable', `HTTP ${res.status}`, res.ok ? 'ok' : 'failed']);
  } catch (err) {
    lines.push(['Cinemeta reachable', err.message, 'failed']);
  }

  const width = Math.max(...lines.map((l) => l[0].length));
  console.log('');
  for (const [label, value, status] of lines) {
    console.log(`  ${label.padEnd(width)}   ${String(value).padEnd(40)} ${status}`);
  }
  console.log('');
}

async function main() {
  const command = process.argv[2] || 'serve';

  if (command === 'build') {
    const force = process.argv.includes('--force');
    if (imdb.indexExists() && !force) {
      console.log('Index already exists. Use --force to rebuild.');
      return;
    }
    const settings = store.readSettings();
    let lastLine = '';
    await imdb.buildIndex({
      minVotes: settings.indexMinVotes,
      onProgress: (state) => {
        const line = `  [${String(state.pct).padStart(3)}%] ${state.message}`;
        if (line !== lastLine) {
          process.stdout.write(`\r${line.padEnd(78)}`);
          lastLine = line;
        }
      },
    });
    process.stdout.write('\n');
    return;
  }

  if (command === 'doctor') {
    await doctor();
    return;
  }

  await serve();
}

// Everything waiting to be written goes to disk however the app stops: Ctrl+C,
// closing its window (Windows sends SIGHUP, then ends the process ~10 s later),
// or a shutdown.
function flushEverything() {
  try { sources.flushAll(); } catch (_) { /* keep going */ }
  try { releases.flush(); } catch (_) { /* keep going */ }
  util.flushAllStores();
}
process.on('exit', flushEverything);
// A stray error in some background task must not take the whole app down
// (and with it every list Stremio reads from this PC): it is written to this
// window, whatever is waiting is saved, and the app carries on.
let strays = 0;
let strayFlushAt = 0;
function stray(kind, err) {
  strays += 1;
  if (strays <= 50 || strays % 100 === 0) console.error(`[${kind}${strays > 50 ? ` #${strays}` : ''}]`, err && err.stack ? err.stack : err);
  if (Date.now() - strayFlushAt > 10000) {
    strayFlushAt = Date.now();
    try {
      flushEverything();
    } catch (_) {
      /* the error is already logged */
    }
  }
}
process.on('unhandledRejection', (err) => stray('unhandled rejection', err));
process.on('uncaughtException', (err) => stray('uncaught error', err));
for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) {
  try {
    process.on(sig, () => {
      flushEverything();
      if (sig === 'SIGINT') console.log('\n  Stopped.');
      process.exit(0);
    });
  } catch (_) {
    /* a signal this platform doesn't have */
  }
}

main().catch((err) => {
  console.error('');
  console.error('  ' + err.message);
  console.error('');
  process.exit(1);
});
