# Stremio Playlist Automator

A local add-on server for Stremio. You build playlists in a page that runs on your own
machine, and install them into Stremio — one add-on per playlist, or all of them as a
single add-on. Runs entirely on `127.0.0.1`. No cloud, no paid services, no npm packages.

## Quick start

1. Double-click **`Start.bat`**. It checks Windows, PowerShell, winget and Node.js,
   installs Node.js LTS through winget if needed, then opens `http://127.0.0.1:7788`.
2. Click **Build index** once (IMDb's public dataset, ~200 MB, a few minutes).
3. Set filters and press **Search** (or Enter). Editing a field never re-runs or resets a
   search — it only marks the results as out of date until you search again.
4. Name it, **Save**, **Install**.

`Start.bat -Doctor` prints diagnostics; `-BuildIndex`, `-InstallStremio`, `-Port 7900` and
`-NoBrowser` do what they say.

---

## Upgrading keeps all your progress

The caches moved from single big JSON files to append-only logs (`data/cache/*.log`).
On first start the old files are imported automatically — including a file truncated by
a crash, and any `*.tmp-*` leftovers from failed Windows renames if they hold newer
data. The old file is kept as `*.pre-log-backup`. Nothing you already populated is
fetched again.

Why the change: the old cache rewrote the **whole** file every few seconds. With 100k+
titles that blocked the server for seconds at a time (the "frozen" scans), triggered the
Windows `EPERM` rename errors, and a crash mid-write could leave an unreadable file that
was then silently discarded. Now each result is one appended line, so writing is
instant, and a crash can lose at most one partial line.

---

## Countries

- **Main country rule (on by default).** A required country must be the title's *first*
  country of origin. *The Revenant* lists Argentina as a co-producer; it is not an
  Argentinian film. With several required countries, any of them in first position
  matches. **Excluded countries ban a title if they appear anywhere**, co-productions
  included. Untick the box to match any position.
- **The full country list**, grouped by region (North America, South America, the Asian
  and African sub-regions, Oceania, plus historical states), alphabetical inside each,
  with a search box and quick-pick buttons for Portuguese- and Spanish-speaking
  countries. Adding another quick pick is one line in `src/lib/countries.js`.
- **Exact names.** "Niger" no longer matches "Nigeria", nor "Sudan" "South Sudan".
  Historical names fold into their successors (West Germany → Germany, Soviet Union →
  Russia, Czechoslovakia → Czech Republic).
- **Populate all countries** fetches every title's data up front. It uses IMDb's own
  GraphQL service in batches of 50 titles per request (the old path was 1 per request),
  and only asks for titles it doesn't already know.

### Is the country data permanent? Does it survive a new IMDb dataset?

Yes. It's stored by IMDb id, completely separate from the index. Rebuild the index with
a newer dataset and every title you already have is still known; only titles that are
new to the dataset are missing. Press **Populate** again and it skips straight to those —
nothing else is fetched. A lookup that fails is never stored as "no data", so it's
retried next time rather than remembered wrongly.

### Does each lookup bring back more than the country?

Yes, at no extra cost. Stremio's metadata response already carried director, cast,
writer, language and **awards** (the old version threw the awards away; it keeps them
now). The IMDb batch request returns, in the same call: ordered countries of origin,
award wins and nominations, the most prestigious award (e.g. Oscars won/nominated),
Metascore, and the **number of written IMDb reviews**. Tick "also awards, Metascore,
review counts" on Populate to fill those in for titles you populated before.

---

## Filters and sorting

- **Vote-farm filters.** *At least N written IMDb reviews* catches the 9.2-with-2,000-
  votes-and-zero-reviews titles directly. Review counts are fetched **in bulk**, 50
  titles per request, by the same Populate button that fills in countries — tick "also
  awards, Metascore, review counts" and it tops up every title you already have. Press
  **Test** next to the field to see IMDb's live answer for one title — if IMDb ever stops returning review counts, the filter says so
  instead of quietly passing everything. The TMDB and Letterboxd corroboration options
  are still there.
- **Multi-key sorting.** Pick a main order, then add up to three **then by** keys
  (e.g. runtime ↓, then rating ↓) used to break ties.
- **Balanced score.** Mix rating, votes, runtime and recency with your own weights. Each
  part is scored by its **rank among the titles your filters matched** (1.00 = the
  longest / highest rated / most voted of them), so nothing is capped: a 9-hour film
  outranks a 4-hour one. *Must be strong at all of them* uses a weighted geometric mean —
  an 8.5 with 800k votes beats both a 9.4 with 900 votes and a 6.0 with 2M. *Strengths
  can offset weaknesses* uses an arithmetic mean instead. Weight 0 leaves a part out.

### Letterboxd ratings

Letterboxd has no public API and no bulk feed — every bulk offering is either a paid
scraping service or a stale third-party dump — so their average can only be read one film
page at a time. Sorting the whole index that way would mean ~276,000 page requests, so
instead there is **re-rank the results by Letterboxd rating**: it reorders the titles your
filters already produced (up to the cap), fetching two pages at a time with the usual
progress and pause controls. First run over 500 titles takes a few minutes; every rating
is then kept forever, so later searches reorder instantly. Films Letterboxd has no rating
for keep their place at the end rather than vanishing.

## Long scans

Titles already in the cache cost nothing and are never limited: a sweep over 170,000
cached titles takes about a second. Only **new network lookups** are budgeted — 15,000
per round, to protect the free APIs. When a round is spent the page says **Paused** and
offers **Continue** or **Continue until done**; it never sits on "still scanning".
Lookups that keep failing are listed under **Show unconfirmed** with a **Retry** button,
instead of being silently lost.

---

## Watched lists

**Hiding watched considers every list you keep, plus your TMDB list** — not only the one
selected in the dropdown. Watchlists are kept strictly separate and never count as
watched. Marking a film watched on its card sends that one title to TMDB immediately and
re-runs the search, so it disappears at once from a hide-watched playlist.

**Exports.** Each playlist, your whole watched set and your watchlist can be exported as
CSV in **IMDb's own export layout**, which both Letterboxd ("Import your data") and TMDB
(Settings → Import list) accept. The internal `Const,Name,Year` files match neither
format, which is why TMDB refused them.

**Watchlist sync** pushes your Letterboxd/IMDb watchlists to TMDB's real watchlist
(falling back to a private list named "Watchlist" if TMDB won't issue the session it
needs), and mirrors TMDB-only entries back into `TMDB Watchlist.csv`.

Any watched list (the dropdown) can hold IMDb exports, a Letterboxd export and your
**Custom Server List** (the Mark-watched button on movie cards).

- **Export from Letterboxd / Export from IMDb** open the site's export page. Click its
  export button there (your own login is needed); the app watches your standard Downloads
  folder (if you've moved it, just drop the file on the page instead) and imports the file the
  moment the download finishes. Results refresh on their own.
- **A new export replaces the old one.** Previously each dated export was kept next to
  the old ones, so a film you removed on Letterboxd stayed "seen" forever.
- **Exact Letterboxd matches.** Each film's Letterboxd page carries its IMDb id. The app
  visits each film once (same idea as the converter script you sent), remembers it for
  good, and only visits films added since the last import. Rows it can't reach yet fall
  back to title + year.
- **TMDB account sync.** TMDB's API has no "watched" flag, so the app keeps a **private
  list called "Watched"** on your account. *Link TMDB account* opens TMDB's approval page
  (needs the long *API Read Access Token* from TMDB → Settings → API in the TMDB key field). *Sync* is
  two-way and incremental: only additions and removals since the last sync are sent;
  titles only on TMDB are mirrored into `TMDB Watched.csv`; a title you delete on TMDB is
  not pushed back, and one you un-mark locally is removed there. Progress, a log and any
  errors are shown. With auto-sync on, every import syncs by itself.

IMDb has no public API for accounts (its official API is a paid AWS product), so IMDb
data comes in through its export file.

---

## Installing into Stremio

**Installing is copy-and-paste.** Press Install and the URL is copied for you, then in
Stremio go to **Add-ons → Community add-ons**, paste it in the box at the top and press
Install. Stremio's own one-click install links rewrite `http://` to `https://`
(Stremio issue #1525), which a local server cannot answer — that is why the button
hands you the URL instead of pretending to install.

- **One add-on per playlist**, or **Install all as one add-on** — a single add-on whose
  rows follow your playlist order (drag the rows, or ▲▼, or reset to creation order,
  which is also the default).
- **What updates live:** filters and sorting. Catalogs are served with no caching, so
  Stremio gets the new results the next time it loads the row.
- **What needs a reinstall:** anything in the add-on's *manifest* — name, films/series
  type, pinned genres, search, adult flag, and for the bundle, adding/removing/reordering
  playlists. Stremio's developers confirm it never re-reads a private add-on's manifest.
  The playlist table marks those installs **reinstall**; one click fixes it.
- If a row still shows old content after that, it's a known Stremio client bug (issue
  #2806, open as of this release): the app is already returning the new list.

## Marking titles while you browse

- **Shift + left-click** a poster or row: put it on your watchlist.
- **Ctrl + right-click**: red-flag it — it stays in the database and in the index, but no
  playlist will ever include it. Ctrl + right-click again to clear the flag.
- Left-click still opens the card, which also has **Mark watched**, **I want to watch**
  and **Red-flag** buttons.
- **See red-flags** (next to the count) opens a window listing everything you have
  flagged: tick any number and press *Remove red flag* to bring them back, or click a
  title to open its card on top. Escape closes the card first, then the list.
- A green ✓ marks watched titles, a violet ★ marks watchlist titles, and red-flagged ones
  are dimmed with a ⚑.

Watchlist entries go to `Custom Watchlist.csv` — never into the watched set — and are
pushed to TMDB straight away, like watched titles are.

**Removing works across every list.** Most entries come from read-only files (a
Letterboxd zip, an IMDb export, the TMDB mirror), which cannot be edited in place, so a
removal is recorded in `data/list-overrides.json` and subtracted from every source. The
title disappears from the results at once and stays gone after a re-import; adding it
again clears the record. Watched and watchlist removals are tracked separately.

## Movie card

Top 3 IMDb reviews (most helpful first, spoilers skipped) and top 3 Letterboxd reviews,
plus Letterboxd's average rating, each linking to its source. IMDb reviews come from its
GraphQL service — its web pages sit behind a bot challenge, which is why the old version
failed for every title. Awards, top award, Metascore and written-review count appear in
the details.

---

## Troubleshooting

| Symptom | What's going on |
| --- | --- |
| `Node.js … not visible to this window yet` | Normal right after a winget install: close the window and run `Start.bat` again. |
| Scan shows **Paused** | A round's budget of new lookups is spent. Press Continue. Cached titles never count. |
| "N couldn't be confirmed" | Their lookups kept failing (network/rate limit). Show them, then Retry. |
| Export didn't import | The watcher waits 20 minutes for a new `letterboxd-*.zip` / IMDb CSV in Downloads. Or just drop the file on the page. |
| TMDB link says it needs the Read Access Token | Replace the short API key with the long API Read Access Token from TMDB → Settings → API. It works for everything. |
| Reviews: "Could not load IMDb/Letterboxd" | That site changed or blocked the request; the other source still shows, and each has an "open" link. |
| Old `EPERM … rename` errors | Gone: caches append instead of renaming, and settings/playlist saves retry and fall back when Windows locks a file. |

## Files

- `data/imdb-index.json` — the local IMDb index. `data/playlists/` — one file per playlist.
- `data/seen/<list>/` — your exports, `Custom Server List.csv`, converted Letterboxd ids,
  `TMDB Watched.csv`. `data/sync/` — the last-sync snapshot used for incremental sync.
- `data/cache/*.log` — every lookup result, kept permanently.

Sources: IMDb datasets and IMDb's public GraphQL service; TMDB (this product uses the TMDB
API but is not endorsed or certified by TMDB); Stremio's Cinemeta; Letterboxd pages;
optional OMDb; MetaHub posters.
