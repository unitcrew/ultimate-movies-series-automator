// Runs on pages of this PC (127.0.0.1 / localhost), but only does anything on
// the Playlist Automator's own page: asks the app for Letterboxd requests,
// has the background make them, and hands the answers back.
(() => {
  if (!document.querySelector('meta[name="plx-app"]')) return;
  const VERSION = chrome.runtime.getManifest().version;
  let busy = false;
  async function post(path, body) {
    const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return r.json();
  }
  async function tick() {
    if (busy) return;
    busy = true;
    let worked = false;
    try {
      const { jobs = [] } = await post('/api/lbhelper/next', { version: VERSION });
      worked = jobs.length > 0;
      await Promise.all(jobs.map(async (job) => {
        let res;
        try {
          res = await chrome.runtime.sendMessage({ type: 'fetch', url: job.url });
        } catch (err) {
          res = { status: 0, error: String((err && err.message) || err) };
        }
        await post('/api/lbhelper/result', { id: job.id, ...(res || { status: 0 }) });
      }));
    } catch (_) {
      /* app restarting: try again next tick */
    } finally {
      busy = false;
      if (worked) setTimeout(tick, 0); // more work waiting: straight on
    }
  }
  setInterval(tick, 700);
  tick();
})();
