// Makes one Letterboxd request at a time, from this browser, with its cookies.
// If Letterboxd ever asks to confirm a person, it opens that film's normal page
// in a tab of this browser (at most once every 2 minutes) so you can.
let lastTab = 0;

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg || msg.type !== 'fetch' || !/^https:\/\/letterboxd\.com\//.test(String(msg.url))) return false;
  (async () => {
    try {
      const r = await fetch(msg.url, { credentials: 'include' });
      const text = await r.text();
      const mitigated = r.headers.get('cf-mitigated') || (r.status === 403 && /challenge-platform|cf-chl/i.test(text) ? 'challenge' : '');
      if (mitigated && Date.now() - lastTab > 120000) {
        lastTab = Date.now();
        const page = msg.url.replace('/csi/film/', '/film/').replace(/rating-histogram\/?$/, '');
        // a tab in the window you're using, never a new window
        chrome.tabs.create({ url: page, active: true });
      }
      send({ status: r.status, url: r.url, text: mitigated ? '' : text, mitigated });
    } catch (err) {
      send({ status: 0, error: String((err && err.message) || err) });
    }
  })();
  return true; // answer comes asynchronously
});
