/**
 * Stremio Playlist Automator — combinable-dropdowns Worker (Cloudflare, free plan).
 *
 * Sits in front of the GitHub Pages site. It decides nothing: the PC ranks
 * and filters every list and publishes, for each playlist with combinable
 * dropdowns switched on (registry: x/combo.json):
 *   facets.json  dropdown options + the names behind each code
 *   index.bin    12 bytes per title in final order: uint32 genre bitmask,
 *                uint16 year, uint16 country code, uint32 offset in titles.bin
 *                (PLX2, festival lists: + uint32 day bitmask, uint32 section bitmask = 20 bytes)
 *   titles.bin   one Stremio meta (JSON) per line
 * For those catalogs this Worker walks index.bin, keeps the titles matching
 * every selected dropdown (genre, year, decade, country — any mix), in the
 * published order, and cuts out the page asked for. An empty combination is
 * an empty list, never an error.
 * Manifests: GitHub's copy of a playlist with combinable dropdowns offers
 * only its first dropdown (fixed files answer it from any address); the
 * registry's "manifests" names the combinable copy this Worker hands out
 * instead. Everything else (plain lists, bundle parts all/, all-2/ …) is
 * passed straight through from GitHub Pages.
 * No sorting, no whole-file parsing: well inside the free plan's 10 ms CPU.
 */

const WORKER_VERSION = 7;
// Where the PC publishes. Replaced with your own site when the app deploys this.
const SITE = 'https://unitcrew.github.io/ultimate-movies-series-automator';
const PAGE = 100;
const FRESH_MS = 5 * 60 * 1000; // re-check GitHub at most every 5 minutes per Worker instance

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': '*',
  'access-control-allow-methods': 'GET, OPTIONS',
};

const memo = new Map(); // url -> { at, value } (lives as long as the Worker instance)

async function load(url, kind) {
  const hit = memo.get(url);
  if (hit && Date.now() - hit.at < FRESH_MS) return hit.value;
  const res = await fetch(url, { cf: { cacheTtl: 300, cacheEverything: true } });
  if (!res.ok) {
    if (hit) return hit.value; // GitHub hiccup: keep serving what we had
    const err = new Error(`${url}: HTTP ${res.status}`);
    err.status = res.status === 404 ? 404 : 502;
    throw err;
  }
  const value = kind === 'json' ? await res.json() : new Uint8Array(await res.arrayBuffer());
  memo.set(url, { at: Date.now(), value });
  return value;
}

function json(obj, status = 200, maxAge = 300) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': `public, max-age=${maxAge}`, ...CORS },
  });
}

/** "genre=Drama&year=2016&skip=100" (one path segment, URI-encoded values). */
function parseExtra(segment) {
  const out = {};
  if (!segment) return out;
  for (const pair of segment.split('&')) {
    const eq = pair.indexOf('=');
    if (eq < 1) continue;
    let k = pair.slice(0, eq);
    let v = pair.slice(eq + 1);
    try {
      k = decodeURIComponent(k);
      v = decodeURIComponent(v);
    } catch (_) {
      /* keep raw */
    }
    out[k] = v;
  }
  return out;
}

const decoder = new TextDecoder();

/** A value this list's dropdowns don't know (e.g. an old install's "genre=2016"). */
class Unknown extends Error {}

async function combined(folder, extra) {
  const base = `${SITE}/${folder}`;
  const [f, index, titles] = await Promise.all([
    load(`${base}/facets.json`, 'json'),
    load(`${base}/index.bin`, 'bin'),
    load(`${base}/titles.bin`, 'bin'),
  ]);

  // Selection -> codes. A genre or country the list doesn't have: let
  // GitHub's fixed files answer (they hold what older installs ask for).
  let mask = 0;
  if (extra.genre) {
    const bit = f.genreBits.indexOf(extra.genre);
    if (bit < 0) throw new Unknown();
    mask = (1 << bit) >>> 0;
  }
  const year = extra.year ? parseInt(extra.year, 10) || -1 : 0;
  const decade = extra.decade ? parseInt(extra.decade, 10) || -1 : 0; // "1990s" -> 1990
  let country = 0;
  if (extra.country) {
    country = f.countries.indexOf(extra.country) + 1;
    if (!country) throw new Unknown();
  }
  // A festival list (PLX2) can also be narrowed by screening day and section.
  const plx2 = f.format === 'PLX2';
  const REC = plx2 ? 20 : 12;
  const bitOf = (list, value) => {
    const b = (list || []).indexOf(value);
    if (!plx2 || b < 0) throw new Unknown();
    return (1 << b) >>> 0;
  };
  const dayMask = extra.day ? bitOf(f.dayBits, extra.day) : 0;
  const sectionMask = extra.section ? bitOf(f.sectionBits, extra.section) : 0;
  const skip = Math.max(0, parseInt(extra.skip, 10) || 0);

  const view = new DataView(index.buffer, index.byteOffset, index.byteLength);
  const count = view.getUint32(4, true);
  const picked = [];
  let seen = 0;
  for (let i = 0; i < count && picked.length < PAGE; i += 1) {
    const at = 8 + i * REC;
    if (mask && !(view.getUint32(at, true) & mask)) continue;
    const y = view.getUint16(at + 4, true);
    if (year && y !== year) continue;
    if (decade && (y < decade || y > decade + 9)) continue;
    if (country && view.getUint16(at + 6, true) !== country) continue;
    if (dayMask && !(view.getUint32(at + 12, true) & dayMask)) continue;
    if (sectionMask && !(view.getUint32(at + 16, true) & sectionMask)) continue;
    if (seen++ < skip) continue;
    picked.push(i);
  }
  const metas = picked.map((i) => {
    const start = view.getUint32(8 + i * REC + 8, true);
    const end = i + 1 < count ? view.getUint32(8 + (i + 1) * REC + 8, true) : titles.length;
    return JSON.parse(decoder.decode(titles.subarray(start, end)));
  });
  return json({ metas });
}

/**
 * The bundle add-ons (all/, all-2/ …) have no files of their own on GitHub:
 * each list is read from its playlist's folder.
 *   /all-2/catalog/movie/<slug>.by-year/year=2016.json
 *   -> /p/<slug>/catalog/movie/playlist.by-year/year=2016.json
 */
function ownCopy(pathname) {
  const m = pathname.match(/^\/all(?:-\d+)?\/catalog\/([a-z]+)\/([a-z0-9-]+)((?:\.by-[a-z]+)?)(\.json|\/[^/]+\.json)$/);
  return versionCompat(m ? `/p/${m[2]}/catalog/${m[1]}/playlist${m[3]}${m[4]}` : pathname);
}

/**
 * A version's dropdown is named "genre" (the only name Stremio's phone app
 * shows). An install from before that asks .../x.by-year/year=2016.json: the
 * same file as .../x.by-year/genre=2016.json.
 */
function versionCompat(pathname) {
  return pathname.replace(/\.by-([a-z]+)\/([^/]+)$/, (all, dim, rest) => `.by-${dim}/${rest.replace(new RegExp(`(^|&)${dim}=`), '$1genre=')}`);
}

/** Anything that isn't a combinable catalog: GitHub Pages, unchanged. */
async function passThrough(pathname, { emptyIfMissing = false } = {}) {
  const res = await fetch(SITE + pathname, { cf: { cacheTtl: 300, cacheEverything: true } });
  if (emptyIfMissing && res.status === 404) return json({ metas: [] });
  const headers = new Headers(CORS);
  headers.set('content-type', res.headers.get('content-type') || 'application/json');
  headers.set('cache-control', 'public, max-age=300');
  return new Response(res.body, { status: res.status, headers });
}

export default {
  async fetch(request) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });
    const url = new URL(request.url);
    try {
      if (url.pathname === '/' || url.pathname === '') {
        return new Response(`Stremio Playlist Automator — combinable dropdowns (Worker v${WORKER_VERSION}).`, { headers: CORS });
      }
      if (url.pathname === '/__version') return json({ version: WORKER_VERSION, site: SITE }, 200, 0);
      const registry = () => load(`${SITE}/x/combo.json`, 'json').catch(() => ({ lists: {}, manifests: {} }));
      // /p/<slug>/manifest.json, /all/manifest.json, /all-2/manifest.json …: the combinable copy when there is one.
      if (url.pathname.endsWith('/manifest.json')) {
        const reg = await registry();
        const alt = reg.manifests && reg.manifests[url.pathname.slice(1)];
        if (alt) return await passThrough(`/${alt}`);
        return await passThrough(url.pathname);
      }
      // /p/<slug>/catalog/<type>/playlist[/<extra>].json  or  /all[-N]/catalog/<type>/<slug>[/<extra>].json
      const m = url.pathname.match(/^\/(p\/[a-z0-9-]+|all(?:-\d+)?)\/catalog\/([a-z]+)\/([a-z0-9.-]+?)(?:\.json|\/([^/]+)\.json)$/);
      if (m) {
        const [, prefix, type, id, extraSeg] = m;
        const reg = await registry();
        // Registry: lists["p/<slug>"] or lists["all-2/<slug>"] = { catalogs: { "<id>": entry } }
        // (one entry per catalog with combinable dropdowns: the playlist and its "· by X" versions).
        const lists = reg.lists || {};
        const slugKey = prefix.startsWith('all') ? `${prefix}/${id.split('.')[0]}` : prefix;
        const holder = lists[slugKey] || lists[`${prefix}/${id}`];
        const entry = holder && (holder.catalogs ? holder.catalogs[id] : holder.catalog === id ? holder : null);
        if (entry && entry.types && entry.types[type]) {
          try {
            // Stremio's names -> what they really are: a version's own dropdown is
            // named "genre" (the only one phones show), a real genre one "category".
            const raw = parseExtra(extraSeg || '');
            let as = entry.as && entry.as[type];
            if (typeof as === 'string') as = { genre: as }; // registry written by v5
            const extra = {};
            for (const [k, v] of Object.entries(raw)) extra[(as && as[k]) || k] = v;
            // Nothing picked on a "· by X" version: its own home row (grouped), a fixed file.
            if (entry.staticRoot && !Object.keys(extra).some((k) => k !== 'skip')) {
              return await passThrough(ownCopy(url.pathname), { emptyIfMissing: true });
            }
            return await combined(entry.types[type], extra);
          } catch (err) {
            if (!(err instanceof Unknown)) throw err;
            return await passThrough(ownCopy(url.pathname), { emptyIfMissing: true });
          }
        }
      }
      return await passThrough(ownCopy(url.pathname));
    } catch (err) {
      return json({ error: String(err.message || err) }, err.status || 500, 10);
    }
  },
};
