@echo off
setlocal
title Stremio Playlist Automator

rem Double-click this file to run everything: checks, installs, then the server.
rem Arguments are forwarded to setup.ps1, for example:
rem     Start.bat -BuildIndex
rem     Start.bat -InstallStremio
rem     Start.bat -Doctor
rem     Start.bat -Port 7900

where powershell >nul 2>&1
if errorlevel 1 (
  echo.
  echo   Windows PowerShell was not found on PATH.
  echo   Open a terminal in this folder and run:  node src\server.js
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
exit /b %errorlevel%
